package com.ing;

public class MyClass {


    public boolean doSomething(){
        if(5<6){
            return true;
        }
        return false;
    }

}
