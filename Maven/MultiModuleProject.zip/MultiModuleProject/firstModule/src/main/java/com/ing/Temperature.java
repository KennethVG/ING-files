package com.ing;

public class Temperature {
    private static final float FREEZING_TEMPERATURE = 0F;
    private static final float BOILING_TEMPERATURE = 100F;

    private float value;

    public Temperature(float value) {
        this.value = value;
    }

    public float getValue() {
        return value;
    }

    public void setValue(float value) throws InvalidTemperatureException {
        if (value < -273.15) {
            throw new InvalidTemperatureException("This value is too low");
        }
        this.value = value;
    }

    public boolean isFreezing() {
        return value <= FREEZING_TEMPERATURE;
    }

    public boolean isBoiling() {
        return value >= BOILING_TEMPERATURE;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Temperature)) return false;

        Temperature that = (Temperature) o;

        return Float.compare(that.getValue(), getValue()) == 0;
    }

    @Override
    public int hashCode() {
        return (getValue() != +0.0f ? Float.floatToIntBits(getValue()) : 0);
    }
}
