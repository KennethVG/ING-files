package com.ing;

public class InvalidTemperatureException extends RuntimeException {

    public InvalidTemperatureException(String message){
        super(message);
    }
}
