package com.ing;

import static org.junit.Assert.*;

import org.junit.*;

public class TemperatureTest {
    private static final float PRECISION = 0.01F;

    private Temperature t;

    @Before
    public void init() {
        t = new Temperature(20);
        System.out.println("BEFORE TEST");
    }

    @Test
    public void testConstructor() {
        assertEquals(20F, t.getValue(), PRECISION);
    }

    @Test
    public void testValue() {
        t.setValue(13F);
        assertEquals(13F, t.getValue(), PRECISION);
    }


    @Test
    public void testIsBoiling(){
        t.setValue(80F);
        assertFalse(t.isBoiling());

        t.setValue(99.9F);
        assertFalse(t.isBoiling());

        t.setValue(100F);
        assertTrue(t.isBoiling());

        t.setValue(100.1F);
        assertTrue(t.isBoiling());
    }

    @Test(expected = InvalidTemperatureException.class)
    public void testException(){
        t.setValue(-300F);
    }
}
