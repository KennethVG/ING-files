package com.ing;

import org.junit.Test;

import static org.junit.Assert.*;

public class HelloTest {

    @Test
    public void testConstructor(){
        Hello hello = new Hello("Hello JUNIT");
        assertEquals("Hello JUNIT", hello.getMessage());
        assertTrue(hello.getMessage() != null);
    }

    @Test
    public void testSetMessage(){
        Hello hello = new Hello();
        hello.setMessage("Hello again!");
        assertEquals("Hello again!", hello.getMessage());
    }


}
