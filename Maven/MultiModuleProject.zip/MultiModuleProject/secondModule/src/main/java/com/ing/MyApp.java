package com.ing;

public class MyApp {

    public static void main(String[] args) {

        Hello hello = new Hello();
        hello.setMessage("Hello World");
        System.out.println(hello.getMessage());



    }
}