package exercise13;

public interface SimpleTest {}
