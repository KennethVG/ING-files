package exercise13;

public interface IntensiveTest {}
