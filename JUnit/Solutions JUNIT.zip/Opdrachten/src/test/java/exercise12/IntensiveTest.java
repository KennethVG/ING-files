package exercise12;

public interface IntensiveTest {}
