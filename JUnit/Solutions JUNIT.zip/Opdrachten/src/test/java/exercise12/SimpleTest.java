package exercise12;

public interface SimpleTest {}
