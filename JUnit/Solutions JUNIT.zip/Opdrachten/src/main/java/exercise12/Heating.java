package exercise12;

public interface Heating {
   public void setHeating(boolean status);
}
