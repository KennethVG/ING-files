package exercise13;

public interface Heating {
   public void setHeating(boolean status);
}
