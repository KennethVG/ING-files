package exercise09;

public interface Heating {
   public void setHeating(boolean status);
}
