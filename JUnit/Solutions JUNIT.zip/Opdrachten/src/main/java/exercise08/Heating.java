package exercise08;

public interface Heating {
   public void setHeating(boolean status);
}
