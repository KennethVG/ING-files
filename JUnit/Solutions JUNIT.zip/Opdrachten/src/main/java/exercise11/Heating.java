package exercise11;

public interface Heating {
   public void setHeating(boolean status);
}
