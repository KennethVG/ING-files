package be.oak3.model;

public class Parfum extends Product {

    public Parfum(int number, String brandName, String name, int volume,
                  double price) {
        super(number, brandName, name, volume, price);
    }
}
