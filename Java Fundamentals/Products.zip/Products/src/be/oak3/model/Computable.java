package be.oak3.model;

@FunctionalInterface
public interface Computable {

	double totalPrice();
}
