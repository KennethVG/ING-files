package collections_02;

public enum GenderType {
   MALE,FEMALE;
}
