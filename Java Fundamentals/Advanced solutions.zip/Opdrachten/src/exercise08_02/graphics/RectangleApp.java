package exercise08_02.graphics;

public class RectangleApp {
	public static void main(String[] args) {
		System.out.println("This program uses a rectangle");
		Rectangle rect = new Rectangle();
	}
}
