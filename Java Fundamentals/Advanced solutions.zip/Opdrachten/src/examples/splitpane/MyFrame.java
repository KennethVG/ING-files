package examples.splitpane;

import javax.swing.*;

public class MyFrame extends JFrame {

   public MyFrame() {
      super("My Application");
      initComponents();
      setVisible(true);
   }

   private void initComponents() {
      ImageIcon icon1 = new ImageIcon("java.jpg");
      ImageIcon icon2 = new ImageIcon("java.png");
      
      JLabel label1 = new JLabel(icon1);
      JLabel label2 = new JLabel(icon2);
      
      JSplitPane pane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,label1,label2);
      add(pane);
      
      setDefaultCloseOperation(EXIT_ON_CLOSE);
      setSize(300, 200);
      setLocation(20, 20);
   }
}