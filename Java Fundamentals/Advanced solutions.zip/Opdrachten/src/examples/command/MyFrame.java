package examples.command;

import java.awt.*;
import javax.swing.*;

public class MyFrame extends JFrame {
   private JTextField textField;
   private MyController controller;
   private JPanel numPanel;
   private JButton[] buttons;

   public MyFrame(MyController controller) {
      super("Actions");
      this.controller = controller;
      initComponents();
      layoutComponents();
      initListeners();
      setVisible(true);
   }

   public void setText(String text) {
      textField.setText(text);
   }

   public String getText() {
      return textField.getText();
   }

   private void initComponents() {
      textField = new JTextField();
      numPanel = new JPanel();
      buttons = new JButton[9];
      for (int i = 0; i < buttons.length; i++) {
         buttons[i] = new JButton(Integer.toString(i+1));
         buttons[i].setActionCommand(Integer.toString(i+1));
      }
      setDefaultCloseOperation(EXIT_ON_CLOSE);
      setSize(300, 200);
      setLocation(20, 20);
   }

   private void layoutComponents() {
      numPanel.setLayout(new GridLayout(3, 3));
      add(textField, BorderLayout.SOUTH);
      add(numPanel, BorderLayout.CENTER);
      for (JButton button : buttons) {
         numPanel.add(button);
      }
   }

   private void initListeners() {
      for (JButton b : buttons) {
         //b.addActionListener(e ->  controller.buttonClicked(e));
         b.addActionListener(controller::buttonClicked);
      }
   }
}
