package examples.command;

import java.awt.event.*;

public class MyController {
   private MyFrame view;
   
   public MyController() {
      init();
   }
   
   private void init() {
      view = new MyFrame(this);
   }
   
   public void buttonClicked(ActionEvent e) {
      String command = e.getActionCommand();
      view.setText(view.getText() + command);
   }   
}
