package examples.adapters;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

public class MyFrame extends JFrame {
   private MyController controller;
   private JLabel textLabel;
   private JPanel panel;

   public MyFrame(MyController controller) {
      super("Adapters");
      this.controller = controller;
      initComponents();
      layoutComponents();
      initListeners();
      setVisible(true);
   }

   public void setText(String text) {
      this.textLabel.setText(text);
   }

   private void initComponents() {
      panel = new JPanel();
      textLabel = new JLabel();
      setSize(300, 200);
      setLocation(20, 20);
   }

   private void layoutComponents() {
      add(textLabel, BorderLayout.SOUTH);
      add(panel, BorderLayout.CENTER);
   }

   private void initListeners() {
      panel.addMouseListener(new MouseAdapter() {
         public void mouseClicked(MouseEvent e) {
            controller.mouseClicked(e);
         }
      });

      this.addWindowListener(new WindowAdapter() {
         public void windowClosing(WindowEvent e) {
            controller.exitApplication();
         }         
      });
   }
}
