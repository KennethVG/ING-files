package examples.adapters;

import java.awt.event.MouseEvent;

public class MyController {
   private MyFrame view;
   
   public MyController() {
      init();
   }
   
   private void init() {
      view = new MyFrame(this);
   }
   
   public void mouseClicked(MouseEvent e) {
      String text ="";
      switch (e.getButton()) {
      case MouseEvent.BUTTON1:
         text = "Left button clicked";
         break;
      case MouseEvent.BUTTON2:
         text = "Middle button clicked";
         break;
      case MouseEvent.BUTTON3:
         text = "Right button clicked";
         break;
      }      
      view.setText(String.format("%s on position (%d,%d)",text, e.getX(),e.getY()));
   }
   
   public void exitApplication() {
      System.exit(0);
   }

   public void mouseEntered(MouseEvent e) {
   }

   public void mouseExited(MouseEvent e)  {
   }

   public void mousePressed(MouseEvent e)  {
   }

   public void mouseReleased(MouseEvent e) {
   }

   
   
}
