package examples.serialization;

import java.io.*;
import java.util.*;

public class Person extends Mammal implements Serializable {
	private String firstName;

	private String lastName;

	private Date birthDay;

	private transient Timer hartbeat;
	
	
	public Person(String fname, String lname, Date birthDay) {
		this.firstName = fname;
		this.lastName = lname;
		this.birthDay = birthDay;
		setLegs(2);
		hartbeat = new Timer(true);
		hartbeat.scheduleAtFixedRate(new Hartbeat(), 0, 1000);
	}

	class Hartbeat extends TimerTask {
		public void run() {
			System.out.print("*");
		}
	}

	public String getFirstName() {
		return firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public Date getBirthDay() {
		return birthDay;
	}

	private void readObject(ObjectInputStream s)
			throws IOException, ClassNotFoundException {
		s.defaultReadObject();
		hartbeat = new Timer(true);
		hartbeat.scheduleAtFixedRate(new Hartbeat(), 0, 1000);
	}
}
