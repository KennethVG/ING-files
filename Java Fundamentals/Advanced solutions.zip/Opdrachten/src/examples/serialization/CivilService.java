
package examples.serialization;

import java.io.*;

public class CivilService {
   public static void main(String[] args) throws Exception {
      String fileName = args[0];
      FileInputStream file = 	new FileInputStream(fileName);
      ObjectInputStream ois = new ObjectInputStream(file);
      Person citizen = (Person) ois.readObject();
      ois.close();
      
      System.out.println(citizen.getFirstName());
      System.out.println(citizen.getLastName());
      System.out.println(citizen.getBirthDay());
      System.out.println(citizen.getLegs());
      
      
      System.in.read();
   }   
}
