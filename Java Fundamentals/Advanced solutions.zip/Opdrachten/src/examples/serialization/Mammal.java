package examples.serialization;

public class Mammal {
	private int legs = 0;
	
	public Mammal() {
		
	}

	public int getLegs() {
		return legs;
	}

	public void setLegs(int legs) {
		this.legs = legs;
	}
	
}
