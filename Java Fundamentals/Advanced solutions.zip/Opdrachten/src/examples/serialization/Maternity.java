package examples.serialization;

import java.io.*;
import java.util.*;

public class Maternity {
   public static void main(String[] args) throws Exception {
      String firstName = args[0];
      String lastName = args[1];
      String fileName = firstName + "_" + lastName + ".ser";
       
      Date birthDay = new Date();
      Person baby = new Person(firstName,lastName,birthDay);
      FileOutputStream file = new FileOutputStream(fileName);
      ObjectOutputStream oos = new ObjectOutputStream(file);
      oos.writeObject(baby);
      oos.close();
      
      System.in.read();
   }
}
