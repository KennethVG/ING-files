package examples.menu;

public class MyApplication {

   public static void main(String[] args) {
      new MyFrame();
   }
}
