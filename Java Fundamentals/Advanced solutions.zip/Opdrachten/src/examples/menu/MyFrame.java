package examples.menu;

import javax.swing.*;

public class MyFrame extends JFrame {
   private JMenuBar menuBar;
   private JMenu menu1;
   private JMenuItem item1_1;
   private JMenuItem item1_2;
   private JMenu menu2;
   private JCheckBoxMenuItem item2_1;
   private JMenu item2_2;
   private JMenuItem item2_2_1;
   private JMenuItem item2_2_2;

   public MyFrame() {
      super("My Application");
      initComponents();
      initMenu();
      setVisible(true);
   }

   private void initComponents() {
      menuBar = new JMenuBar();
      menu1 = new JMenu("Menu 1");
      item1_1 = new JMenuItem("Item 1_1");
      item1_2 = new JMenuItem("Item 1_2");
      menu2 = new JMenu("Menu 2");
      item2_1 = new JCheckBoxMenuItem("Item 2_1");
      item2_2 = new JMenu("Item 2_2");
      item2_2_1 = new JMenuItem("Item 2_2_1");
      item2_2_2 = new JMenuItem("Item 2_2_2");
            
      setDefaultCloseOperation(EXIT_ON_CLOSE);
      setSize(300, 200);
      setLocation(20, 20);
   }
   private void initMenu() {
      setJMenuBar(menuBar);
      menuBar.add(menu1);
      menu1.add(item1_1);
      menu1.add(item1_2);
      menuBar.add(menu2);
      item2_2.add(item2_2_1);
      item2_2.add(item2_2_2);
      menu2.add(item2_1);
      menu2.add(item2_2);
   }
}