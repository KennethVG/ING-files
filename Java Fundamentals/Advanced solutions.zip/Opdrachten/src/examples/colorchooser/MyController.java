package examples.colorchooser;

import java.awt.*;

import javax.swing.*;

public class MyController {
   private MyFrame view;

   public MyController() {
      init();
   }

   private void init() {
      view = new MyFrame(this);
   }

   public void buttonClicked() {
      Color color = JColorChooser.showDialog(view,
            "Choose color", null);
      System.out.println(color);
   }
}
