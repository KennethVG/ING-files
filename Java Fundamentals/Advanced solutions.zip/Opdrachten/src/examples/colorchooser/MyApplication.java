package examples.colorchooser;

public class MyApplication {
   public static void main(String[] args) {
      new MyController();
   }
}
