package examples.colorchooser;

import java.awt.event.*;
import javax.swing.*;

public class MyFrame extends JFrame {
   private JButton button;
   private MyController controller;

   public MyFrame(MyController controller) {
      super("Dialog");
      this.controller = controller;
      initComponents();
      layoutComponents();
      initListeners();
      setVisible(true);
   }

   private void initComponents() {
      button = new JButton("Click to open Dialog");
      setDefaultCloseOperation(EXIT_ON_CLOSE);
      setSize(300, 200);
      setLocation(20, 20);
   }

   private void layoutComponents() {
      add(button);
   }

   private void initListeners() {
      button.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            controller.buttonClicked();
         }         
      });
   }
}
