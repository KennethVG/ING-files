package examples.multithreading;

public class PrintApp {
	public static void main(String[] args) {
		Thread myThread1 = new Thread(() -> print('#',100));
		Thread myThread2 = new Thread(() -> print('*',100));
		myThread1.start();
		myThread2.start();
		
	}
	
	public static void print(char c, int count) {
	   for(int i = 0 ; i< count; i++) {
	      System.out.print(c);
	   }
	}
}
