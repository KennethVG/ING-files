package examples.animation;

import java.awt.*;
import java.util.*;

import javax.swing.*;
import java.util.Timer;

public class CarApplication extends JFrame {
	private Image image;
	private int x;
	private int y;
	private MyComponent area;

	public static void main(String[] args) {
		new CarApplication("My Application");
	}

	public CarApplication(String text) {
		super(text);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setSize(400, 300);
		setLocation(20, 20);
		Container pane = getContentPane();
		area = new MyComponent();
		pane.add(area);
		image = Toolkit.getDefaultToolkit().getImage("auto.jpg");
		setVisible(true);

		TimerTask animation = new AnimationTask();
		Timer timer = new Timer(true);
		timer.scheduleAtFixedRate(animation, 50, 50);
	}

	class AnimationTask extends TimerTask {
		public void run() {
			if (++x >= area.getWidth()) {
				x = 0;
			}
			area.repaint();
		}
	}

	class MyComponent extends JComponent {
		public void paintComponent(Graphics g) {
			g.clearRect(0, 0, getWidth(), getHeight());
			g.drawImage(image, x, y, this);
		}
	}
}