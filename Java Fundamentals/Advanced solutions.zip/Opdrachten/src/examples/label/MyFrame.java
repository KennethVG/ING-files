package examples.label;

import javax.swing.*;

public class MyFrame extends JFrame {

   public MyFrame() {
      super("My Application");
      initComponents();
   }

   private void initComponents() {
      ImageIcon icon = new ImageIcon("ok-icon.png");
      add(new JLabel(icon));
      setDefaultCloseOperation(EXIT_ON_CLOSE);
      setSize(300, 200);
      setLocation(20, 20);
      setVisible(true);
   }
}