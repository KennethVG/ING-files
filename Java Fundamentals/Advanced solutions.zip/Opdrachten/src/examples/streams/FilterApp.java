package examples.streams;

import java.util.function.Predicate;
import java.util.stream.*;

public class FilterApp {

   public static void main(String[] args) {

      
      String[] words = {"Hello","this","is","an","example","of","streams"};
      
		Stream<String> stream = Stream.of(words);		
      Stream.of(words).forEach(System.out::println);
      
      IntStream.rangeClosed(0,10)
                .forEach(System.out::println);

      Predicate<String> predicate = s -> s.contains("e");
      Stream<String> filteredStream = Stream.of(words).filter(predicate);
      filteredStream.forEach(System.out::println);
      

      Stream.of(words).filter(s -> s.contains("e"))
                      .forEach(System.out::println);

      Stream.of(words).filter(s -> s.length() > 3)
                      .filter(s -> s.contains("e"))
                      .forEach(System.out::println);


      Stream.of(words).filter(s -> s.length() > 3)
                      .limit(3)
                      .forEach(System.out::println);
      
      IntStream.iterate(0, i -> i + 3).limit(100).forEach(System.out::println);
      
      Stream.of(words).mapToInt(String::length).forEach(System.out::println);
      
      Stream.of(words).map(String::toUpperCase).forEach(System.out::println);
      
   }
}
