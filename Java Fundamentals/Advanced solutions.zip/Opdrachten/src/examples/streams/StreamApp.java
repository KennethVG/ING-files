package examples.streams;

import java.util.*;
import java.util.function.Predicate;
import java.util.stream.*;

public class StreamApp {

   public static void main(String[] args) {

      
      String[] words = {"Hello","this","is","an","example","of","streams"};
		for (String w : words) {
			System.out.println(w);
		}      
      
      
//      Consumer<String> consumer = s -> System.out.println(s);
//      // Consumer<String> consumer = System.out::println;
//
//        Stream.of(words).forEach(consumer);
//
		Stream<String> stream = Stream.of(words);		
      Stream.of(words).forEach(System.out::println);
      
      IntStream.rangeClosed(0,10)
                .forEach(System.out::println);
      
      

      Predicate<String> predicate = s -> s.contains("e");
      Stream<String> filteredStream = Stream.of(words).filter(predicate);
      filteredStream.forEach(System.out::println);

      Stream.of(words).filter(s -> s.contains("e")).forEach(System.out::println);

      Stream.of(words).filter(s -> s.length() > 3).filter(s -> s.contains("e"))
            .forEach(System.out::println);

      Stream.of(words).mapToInt(String::length).forEach(System.out::println);

      int length = Stream.of(words).mapToInt(String::length).sum();
      System.out.println(length);
      
      Stream.of(words).map(String::toUpperCase).forEach(System.out::println);
      
      OptionalInt min = Stream.of(words).mapToInt(String::length).min();
      if(min.isPresent()) {
         System.out.println(min.getAsInt());
      }

      OptionalInt max = Stream.of(words).mapToInt(String::length).max();
      if(max.isPresent()) {
         System.out.println(max.getAsInt());
      }

      OptionalDouble avg = Stream.of(words).mapToInt(String::length).average();
      if(avg.isPresent()) {
         System.out.println(avg.getAsDouble());
      }

      String total = Stream.of(words).reduce("", (String r, String w) -> r+w);
      System.out.println(total);

      Stream.of(words).sorted().forEach(System.out::println);
      
   }
}
