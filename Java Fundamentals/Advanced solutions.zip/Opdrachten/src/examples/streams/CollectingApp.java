package examples.streams;

import java.util.stream.*;

public class CollectingApp {

	public static void main(String[] args) {

		String[] words = { "Hello", "this", "is", "an", "example", "of", "streams" };
		for (String w : words) {
			System.out.println(w);
		}

		String[] array = Stream.of(words).toArray( size -> new String[size]);
		
		//String[] array = Stream.of(words).toArray(String[]::new);
		
		int[] numbers = IntStream.of(5,8,9,4,6).toArray();
		
		
		
		
	}
}
