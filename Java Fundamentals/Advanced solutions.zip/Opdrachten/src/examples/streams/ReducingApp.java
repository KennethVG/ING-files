package examples.streams;

import java.util.*;
import java.util.stream.*;

public class ReducingApp {

	public static void main(String[] args) {

		String[] words = { "Hello", "this", "is", "an", "example", "of", "streams" };
		for (String w : words) {
			System.out.println(w);
		}

		Stream<String> stream = Stream.of(words);

		int sum = IntStream.rangeClosed(0, 10).sum();
		System.out.println(sum);
		OptionalInt max = IntStream.rangeClosed(0, 10).max();
		if(max.isPresent()) {
			System.out.println(max.getAsInt());
		} else {
			System.out.println("No result");
		}

		OptionalInt max2 = IntStream.of().max();
		if(max2.isPresent()) {
			System.out.println(max2.getAsInt());
		} else {
			System.out.println("No result");
		}
		
		OptionalDouble avg = IntStream.rangeClosed(0, 10).average();
		
		int result = IntStream.rangeClosed(1, 10).reduce(1,(acc,el) -> acc*el);
		
		String res = Stream.of(words).reduce("*",(acc,el) -> acc + el + "*");
		System.out.println(res);
		
		
		
		
	}
}
