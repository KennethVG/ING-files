package examples.streams;

import java.util.stream.*;

public class ConsumerApp {

	public static void main(String[] args) {

		String[] words = { "Hello", "this", "is", "an", "example", "of", "streams" };
		for (String w : words) {
			System.out.println(w);
		}

		// Consumer<String> consumer = s -> System.out.println(s);
		// // Consumer<String> consumer = System.out::println;
		//
		// Stream.of(words).forEach(consumer);
		//

		Stream<String> stream = Stream.of(words);
		Stream.of(words).forEach(System.out::println);

		IntStream.rangeClosed(0, 10).forEach(System.out::println);
	}
}
