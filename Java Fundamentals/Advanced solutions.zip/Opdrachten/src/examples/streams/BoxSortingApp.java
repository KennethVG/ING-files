package examples.streams;

import java.util.*;
import java.util.function.*;
import java.util.stream.*;

public class BoxSortingApp {

   public static void main(String[] args) {
      List<Box> boxes = new ArrayList<>();
      
      
      boxes.add(new Box(3, 5, 2));
      boxes.add(new Box(3, 6, 8));
      boxes.add(new Box(3, 6, 10));
      boxes.add(new Box(3, 5, 1));
      boxes.add(new Box(4, 3, 6));
      boxes.add(new Box(4, 3, 8));
      boxes.add(new Box(4, 8, 5));
      boxes.add(new Box(4, 8, 2));
      
      
      Stream<Box> stream = boxes.stream();
      Consumer<Box> consumer = (Box b) -> System.out.println(b);
      stream.forEach(consumer);
      

   }

}
