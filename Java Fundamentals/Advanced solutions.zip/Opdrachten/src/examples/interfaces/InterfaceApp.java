package examples.interfaces;

public class InterfaceApp {

   public static void main(String[] args) {
      int a = MyClass.CONST;
      MyInterface.staticMethod();
      
   }

}
