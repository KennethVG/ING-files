package examples.interfaces;

public interface Interface2 {
   public final int CONST = 1;
   
   public void method2();
}
