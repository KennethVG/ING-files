package examples.interfaces;

public interface PigFactory {
   public static Pig getInstance() {
      return new Pig() {

         @Override
         public void grunt() {
            System.out.println("Oink");
         }
        
      };
   }

}
