package examples.interfaces;

public class PigApplication {

   public static void main(String[] args) {
      Pig pig = PigFactory.getInstance();
      pig.grunt();
      pig.fly();
      
   }

}
