package examples.interfaces;

public class MyClass implements MyInterface  {

   public void method() {
      System.out.println("call of method()");
   }
}
