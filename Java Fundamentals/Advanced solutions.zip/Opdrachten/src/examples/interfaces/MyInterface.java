package examples.interfaces;

public interface MyInterface {
   public final int CONST = 1;
   
   public void method();
   
   public static void staticMethod() {
      System.out.println("call of staticMethod()");
   }
}
