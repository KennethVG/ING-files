package examples.interfaces;

public interface Pig {
   public void grunt();

   public default void fly() {
      System.out.println("Yes pigs can fly");
   }
}
