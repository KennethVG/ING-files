package examples.collections;

import java.util.*;

public class AutoBoxingApp {

   public static void main(String[] args) {
      List<Integer> list = new ArrayList<Integer>();
      list.add(2);
      list.add(5);
      
   }
}
