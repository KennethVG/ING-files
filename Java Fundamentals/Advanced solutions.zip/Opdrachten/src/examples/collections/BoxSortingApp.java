package examples.collections;

import java.util.*;

public class BoxSortingApp {

   public static void main(String[] args) {
      // SortedSet<Box> boxes = new TreeSet<>();

      // SortedSet<Box> boxes = new TreeSet<>(new BoxLengthComparator());

      // SortedSet<Box> boxes = new TreeSet<>(new Comparator<Box>() {
      // @Override
      // public int compare(Box box1, Box box2) {
      // return box1.getWidth() - box2.getWidth();
      // }
      // });

      // SortedSet<Box> boxes = new TreeSet<>((box1,box2) -> box1.getWidth() -
      // box2.getWidth());
      // SortedSet<Box> boxes = new TreeSet<>(Comparator.comparingInt( b ->
      // b.getWidth()));

      // ToIntFunction<Box> widthExtract = b -> b.getWidth();
      // Comparator<Box> comparator = Comparator.comparingInt(widthExtract) ;
      // SortedSet<Box> boxes = new TreeSet<>(comparator);

//      ToIntFunction<Box> lExtract = b -> b.getLength();
//      ToIntFunction<Box> wExtract = b -> b.getWidth();
//      ToIntFunction<Box> hExtract = b -> b.getHeight();
      //
//       Comparator<Box> lComp = Comparator.comparingInt(lExtract) ;
//       Comparator<Box> lwComp = lComp.thenComparingInt(wExtract);
//       Comparator<Box> hlwComp = lwComp.thenComparingInt(hExtract);
      //
      // SortedSet<Box> boxes = new TreeSet<>(hlwComp);


//      SortedSet<Box> boxes = new TreeSet<>(Comparator
//            .comparingInt((Box b) -> b.getLength())
//            .thenComparingInt((Box b) -> b.getWidth())
//            .thenComparingInt((Box b) -> b.getHeight()));

      SortedSet<Box> boxes = new TreeSet<>(Comparator
            .comparingInt(Box::getLength)
            .thenComparingInt(Box::getWidth)
            .thenComparingInt(Box::getHeight));
      

      boxes.add(new Box(3, 5, 2));
      boxes.add(new Box(3, 6, 8));
      boxes.add(new Box(3, 6, 10));
      boxes.add(new Box(3, 5, 1));
      boxes.add(new Box(4, 3, 6));
      boxes.add(new Box(4, 3, 8));
      boxes.add(new Box(4, 8, 5));
      boxes.add(new Box(4, 8, 2));
      boxes.forEach(System.out::println);
   }
}
