package examples.collections;

import java.util.*;

public class ArrayListApp {

   public static void main(String[] args) {
      List<String> list = new ArrayList<String>();
      String text = new String("Hello World");
      list.add(text);
      list.add(text);
      System.out.println(list.size());
      list.remove(text);
      System.out.println(list.size());    
   }
}
