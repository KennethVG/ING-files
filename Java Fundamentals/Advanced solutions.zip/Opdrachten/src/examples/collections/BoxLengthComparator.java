package examples.collections;

import java.util.*;

public class BoxLengthComparator implements Comparator<Box> {

   @Override
   public int compare(Box box1, Box box2) {
      return box1.getLength() - box2.getLength();
   }
}
