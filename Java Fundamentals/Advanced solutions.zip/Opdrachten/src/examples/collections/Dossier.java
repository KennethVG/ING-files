package examples.collections;

public class Dossier {
   private String comments;
   
   public Dossier(String comments) {
      this.comments = comments;
   }

   public String getComments() {
      return comments;
   }

   public void setComments(String comments) {
      this.comments = comments;
   }

   @Override
   public String toString() {
      return String.format("Dossier [comments=%s]", comments);
   }
   
   

}
