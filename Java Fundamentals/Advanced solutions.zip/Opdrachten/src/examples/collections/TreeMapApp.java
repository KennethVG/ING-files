package examples.collections;

import java.util.*;

public class TreeMapApp {

   public static void main(String[] args) {
      SortedMap<String,Dossier> dossiers = new TreeMap<>();      
      dossiers.put("John", new Dossier("Nice guy"));
      dossiers.put("Ellen", new Dossier("Goodlooking woman"));
      dossiers.put("Sue", new Dossier("Mother of 4 children"));
      
      for(String name: dossiers.keySet()) {
         System.out.println(name);
         Dossier d = dossiers.get(name);
         System.out.println(d.getComments());
      }
      
      
      System.out.println(dossiers.get(dossiers.firstKey()));
      System.out.println(dossiers.get(dossiers.lastKey()));
      
      
   }

}
