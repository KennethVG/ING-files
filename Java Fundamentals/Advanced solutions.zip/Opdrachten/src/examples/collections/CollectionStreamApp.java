package examples.collections;

import java.util.*;
import java.util.stream.Collectors;

public class CollectionStreamApp {

	public static void main(String[] args) {
		List<String> words = new ArrayList<>();
		words.add("Hello");
		words.add("this");
		words.add("is");
		words.add("an");
		words.add("example");
		words.add("of");
		words.add("streams");

		words.stream().filter(s -> s.contains("e"))	// filter
		              .sorted()								// sort
		              .map( e -> "<"+ e + ">")			// map
		              .forEach(System.out::println);	// consume
		
		List<String> list =  words.stream().filter(s -> s.contains("e"))	// filter
                                         .sorted()								// sort
                                         .map( e -> "<"+ e + ">")			// map
                                         .collect(Collectors.toList());	// collect
		list.forEach(System.out::println);
	}
}
