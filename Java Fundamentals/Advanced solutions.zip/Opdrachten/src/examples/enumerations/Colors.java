package examples.enumerations;

public class Colors {
   public final static int BLACK = 0;
   public final static int WHITE = 1;
   public final static int RED = 2;
   public final static int GREEN = 3;
   public final static int BLUE = 4;
   public final static int YELLOW = 5;

   public static void main(String[] args) {
      int color = GREEN;
      printColor(color);
   }

   public static void printColor(int color) {
      String text = null;
      switch (color) {
      case BLACK:
         text = "Black";
         break;
      case WHITE:
         text = "White";
         break;
      case RED:
         text = "Red";
         break;
      case GREEN:
         text = "Green";
         break;
      case BLUE:
         text = "Blue";
         break;
      case YELLOW:
         text = "Yellow";
         break;
      }

      System.out.println(text);
   }

}
