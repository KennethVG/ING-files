package examples.enumerations;

public enum Color {
   BLACK(0x000000) {
      public String toString() {
         return "Black";
      }
   },
   WHITE(0xFFFFFF),
   RED(0xFF0000),
   GREEN(0x00FF00),
   BLUE(0x0000FF),
   YELLOW(0xFFFF00);
   
   private int rgb;
   
   private Color(int rgb) {
      this.rgb = rgb;
   }
   
   public int getRgb() {
      return rgb;
   }
   
   public String toString() {
      return name() + "(" + Integer.toHexString(rgb) + ")";
   }
}
