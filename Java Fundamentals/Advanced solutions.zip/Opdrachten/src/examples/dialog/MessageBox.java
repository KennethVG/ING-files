package examples.dialog;

import java.awt.*;

import javax.swing.*;

public class MessageBox extends JDialog {
	public MessageBox(Frame owner, String text) {
		super(owner, "Message", true);
		add(new JLabel(text));
		pack();
	}
}
