package examples.dialog;


public class MyController {
   private MyFrame view;

   public MyController() {
      init();
   }

   private void init() {
      view = new MyFrame(this);
   }

   public void buttonClicked() {
      MessageBox msg = new MessageBox(view, "This is a dialog window.");
      msg.setVisible(true);
   }
}
