package examples.flowlayout;

import java.awt.*;

import javax.swing.*;

public class MyFrame extends JFrame {

   private JButton button1;
   private JButton button2;
   private JTextField textField;

   public MyFrame() {
      super("FlowLayout");
      initComponents();
      layoutComponents();
      setVisible(true);
   }

   private void initComponents() {
      button1 =new JButton("Button 1");
      button2 =new JButton("Button 2");
      textField= new JTextField(10);

      setDefaultCloseOperation(EXIT_ON_CLOSE);
      setSize(400, 200);
      setLocation(20, 20);
   }

   private void layoutComponents() {
      setLayout(new FlowLayout());
      add(button1);
      add(textField);
      add(button2);
   }

}