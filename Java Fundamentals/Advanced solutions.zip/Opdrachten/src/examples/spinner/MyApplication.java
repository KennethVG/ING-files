package examples.spinner;

public class MyApplication {

   public static void main(String[] args) {
      new MyFrame();
   }
}
