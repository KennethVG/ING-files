package examples.filechooser;

import javax.swing.*;

public class MyController {
   private MyFrame view;

   public MyController() {
      init();
   }

   private void init() {
      view = new MyFrame(this);
   }

   public void buttonClicked() {
      JFileChooser dialog = new JFileChooser();
      int result = dialog.showOpenDialog(view);
      if (result == JFileChooser.APPROVE_OPTION) {
         System.out.println("Open file " + dialog.getSelectedFile());
      } else {
         System.out.println("Canceled");
      }
   }
}
