package examples.repaint;

import java.awt.event.*;

public class MyController {
   private MyFrame view;

   public MyController() {
      init();
   }

   private void init() {
      view = new MyFrame(this);
   }
   
   public void mousePressed(MouseEvent e) {
      MyComponent comp = view.getMyComponent();
      comp.setX(e.getX());
      comp.setY(e.getY());
      comp.repaint(e.getX(),e.getY(),51,51);
   }
}

