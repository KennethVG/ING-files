package examples.mouseevent;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

public class MyApplication extends JFrame {
	private JTextArea textArea;

	public static void main(String[] args) {
		new MyApplication("My Application");
	}

	public MyApplication(String text) {
		super(text);
		setDefaultCloseOperation(EXIT_ON_CLOSE);

		setSize(400, 300);
		setLocation(20, 20);

		Container pane = getContentPane();
		JPanel area = new JPanel();
		area.setPreferredSize(new Dimension(400, 100));
		pane.add(BorderLayout.SOUTH, area);
		textArea = new JTextArea();
		pane.add(BorderLayout.CENTER, textArea);

		area.addMouseListener(new MyMouseListener());

		setVisible(true);
	}

	class MyMouseListener extends MouseAdapter {
		public void mouseClicked(MouseEvent e) {
			String position = "(" + e.getX() + "," + e.getY() + ")";
			switch (e.getButton()) {
			case MouseEvent.BUTTON1:
				textArea.append("\nLinker knop geklikt" + position);
				break;
			case MouseEvent.BUTTON2:
				textArea.append("\nMiddelste knop geklikt" + position);
				break;
			case MouseEvent.BUTTON3:
				textArea.append("\nRechter knop geklikt" + position);
				break;
			}
		}
	}
}
