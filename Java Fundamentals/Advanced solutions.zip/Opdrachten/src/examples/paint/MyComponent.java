package examples.paint;

import java.awt.Graphics;
import javax.swing.JComponent;

public class MyComponent extends JComponent {
   public void paintComponent(Graphics g) {
      g.drawRect(30, 30, 50, 50);
   }
}
