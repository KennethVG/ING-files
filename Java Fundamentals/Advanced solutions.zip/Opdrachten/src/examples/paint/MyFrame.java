package examples.paint;

import javax.swing.*;

public class MyFrame extends JFrame {
   private MyController controller;
   private MyComponent myComponent;

   public MyFrame(MyController controller) {
      super("My Application");
      this.controller = controller;
      initComponents();
      layoutComponents();
      initListeners();
      setVisible(true);
   }

   private void initComponents() {
      myComponent = new MyComponent();
      setDefaultCloseOperation(EXIT_ON_CLOSE);
      setSize(300, 200);
      setLocation(20, 20);
   }

   private void layoutComponents() {
      add(myComponent);
   }

   private void initListeners() {
   }
}
