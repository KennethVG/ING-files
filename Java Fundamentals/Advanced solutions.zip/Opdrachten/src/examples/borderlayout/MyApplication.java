package examples.borderlayout;

public class MyApplication {

   public static void main(String[] args) {
      new MyFrame();
   }
}
