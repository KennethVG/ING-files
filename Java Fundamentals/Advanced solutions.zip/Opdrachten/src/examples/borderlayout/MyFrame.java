package examples.borderlayout;

import java.awt.*;

import javax.swing.*;

public class MyFrame extends JFrame {
   private JButton northButton;
   private JButton southButton;
   private JButton eastButton;
   private JButton westButton;
   private JButton centerButton;
      
   public MyFrame() {
      super("BorderLayout");
      initComponents();
      layoutComponents();
      setVisible(true);
   }

   private void initComponents() {
      northButton =new JButton("North");
      southButton =new JButton("South");
      eastButton =new JButton("East");
      westButton =new JButton("West");
      centerButton =new JButton("Center");

      setDefaultCloseOperation(EXIT_ON_CLOSE);
      setSize(300, 200);
      setLocation(20, 20);
   }
   
   private void layoutComponents() {
      
      add(northButton,BorderLayout.NORTH);
      add(southButton,BorderLayout.SOUTH);
      add(eastButton,BorderLayout.EAST);
      add(westButton,BorderLayout.WEST);
      add(centerButton,BorderLayout.CENTER);      
   }
   
}