package examples.mvc.higherlower.view.console;

import java.util.*;

import examples.mvc.higherlower.model.*;
import examples.mvc.higherlower.model.HigherLowerGame.Result;

public class HigerhLowerConsole {

   public static void main(String[] args) {
      HigherLowerGame game = new HigherLowerGame(10);
      Scanner scanner = new Scanner(System.in);
      HigherLowerGame.Result result = null;
      do {
         boolean repeat = false;
         int value = 0;
         do {
            System.out.println("Enter a number between 0 and 10");
            repeat = false;
            if (scanner.hasNextInt()) {
               value = scanner.nextInt();
            } else {
               System.out.println("Invalid value: " + scanner.next());
               repeat = true;
            }
         } while (repeat);
         result = game.guess(value);
         switch (result) {
         case LOWER:
            System.out.println("Lower!");
            break;
         case HIGHER:
            System.out.println("Higher!");
            break;
         case EQUAL:
            System.out.println("Correct!");
            break;
         }

      } while (result != Result.EQUAL);
      scanner.close();
   }
}
