package examples.mvc.higherlower.view.swing;

import java.awt.*;

import javax.swing.*;

public class HigherLowerFrame extends JFrame {
   private HigherLowerController controller;
   private JTextArea displayArea;
   private JTextField inputField;
   private JButton resetButton;
   private JMenuBar menuBar;
   private JMenu menu;
   private JMenuItem resetItem;

   public HigherLowerFrame(HigherLowerController controller) {
      super("Higher - Lower");
      this.controller = controller;
      initComponents();      
      layoutComponents();
      initMenu();
      initListeners();
      setVisible(true);
   }

   public void setDisplayText(String text) {
      displayArea.setText(text);
   }

   public String getDisplayText() {
      return displayArea.getText();
   }

   public String getInputText() {
      return inputField.getText();
   }

   public void setInputText(String text) {
      inputField.setText(text);
   }

   private void initComponents() {
      resetButton = new JButton("New Game");
      displayArea = new JTextArea();
      displayArea.setEditable(false);
      inputField = new JTextField();

      menuBar = new JMenuBar();
      menu = new JMenu("Game");
      resetItem  = new JMenuItem("New Game");
      
      setDefaultCloseOperation(EXIT_ON_CLOSE);
      setSize(300, 200);
      setLocation(20, 20);
   }

   private void layoutComponents() {
      add(resetButton, BorderLayout.NORTH);
      JScrollPane scrollPane = new JScrollPane(displayArea);
      add(scrollPane, BorderLayout.CENTER);
      add(inputField, BorderLayout.SOUTH);
   }

   private void initMenu() {      
      setJMenuBar(menuBar);
      menuBar.add(menu);
      menu.add(resetItem);      
   }
   
   private void initListeners() {
      resetButton.addActionListener(e -> controller.reset());
      resetItem.addActionListener(e -> controller.reset());
      inputField.addActionListener(e -> controller.guess());
   }
}
