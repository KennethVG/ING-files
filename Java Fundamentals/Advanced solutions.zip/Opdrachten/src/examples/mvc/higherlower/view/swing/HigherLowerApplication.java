package examples.mvc.higherlower.view.swing;

public class HigherLowerApplication {
   public static void main(String[] args) {
      new HigherLowerController();
   }
}
