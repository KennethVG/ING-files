package examples.lambda;

public class TextApp {

   public static void main(String[] args) {
      final String c = "e";

      TextPrinter textPrinter = new TextPrinter(
            "Hello this is an example of a sentence containing words");

      System.out.println("*** Words containing 'e' ***");
      textPrinter.printFilteredWords(new WordFilter() {
         @Override
         public boolean isValid(String s) {
            return s.contains(c);
         }
      });
      textPrinter.printFilteredWords(s -> s.contains(c)) ;
      
      System.out.println("*** Long words ***");
      textPrinter.printFilteredWords(new WordFilter() {
         @Override
         public boolean isValid(String s) {
            return s.length()  > 4;
         }
      });
      textPrinter.printFilteredWords(s -> s.length()  > 4) ;
      
      System.out.println("*** Words starting with 'a' ***");
      textPrinter.printFilteredWords(new WordFilter() {
         @Override
         public boolean isValid(String s) {
            return s.startsWith("a");
         }
      });
      textPrinter.printFilteredWords(s -> s.startsWith("a")) ;
   }
}
