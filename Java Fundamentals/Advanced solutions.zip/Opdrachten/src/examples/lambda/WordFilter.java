package examples.lambda;

@FunctionalInterface
public interface WordFilter {
   public boolean isValid(String s);
}
