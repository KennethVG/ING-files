package examples.scrollpane;

import java.awt.*;

import javax.swing.*;

public class MyFrame extends JFrame {

   public MyFrame() {
      super("My Application");
      initComponents();
   }

   private void initComponents() {
      ImageIcon icon = new ImageIcon("java.jpg");
      JLabel label = new JLabel(icon);
      label.setPreferredSize(new Dimension(290,180));
      JScrollPane pane = new JScrollPane(label);
      add(pane);
      
      setDefaultCloseOperation(EXIT_ON_CLOSE);
      setSize(300, 200);
      setLocation(20, 20);
      setVisible(true);
   }
}