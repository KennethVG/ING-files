package examples.image;

import java.awt.*;
import javax.swing.JComponent;

public class MyComponent extends JComponent {
   private Image image;
   
   public MyComponent() {
      image = Toolkit.getDefaultToolkit().getImage("auto.jpg");
   }
   
   public void paintComponent(Graphics g) {
      g.clearRect(0,0,getWidth(),getHeight());
      g.drawImage(image,10,10,this);
   }
}
