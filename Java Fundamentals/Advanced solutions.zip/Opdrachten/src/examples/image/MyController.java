package examples.image;

import javax.swing.*;


public class MyController {
   private MyFrame view;

   public MyController() {
      init();
   }

   private void init() {
      view = new MyFrame(this);
   }

   public void buttonClicked() {
      JOptionPane.showMessageDialog(view, "This is my information dialog!",
            "Message", JOptionPane.INFORMATION_MESSAGE);
   }
}
