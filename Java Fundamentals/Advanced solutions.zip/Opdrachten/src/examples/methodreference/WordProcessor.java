package examples.methodreference;

@FunctionalInterface
public interface WordProcessor {
   public String process(String s);
}
