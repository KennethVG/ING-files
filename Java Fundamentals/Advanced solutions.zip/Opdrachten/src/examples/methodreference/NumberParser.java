package examples.methodreference;

@FunctionalInterface
public interface NumberParser {
   public Long parse(String s);
}
