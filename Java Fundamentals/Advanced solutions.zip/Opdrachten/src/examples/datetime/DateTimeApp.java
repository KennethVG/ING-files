package examples.datetime;

import java.time.*;
import java.time.format.*;

public class DateTimeApp {

   public static void main(String[] args) {
      DateTimeFormatter df =DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
      LocalDateTime time = LocalDateTime.now();
      System.out.println(time.format(df));      
   }
}
