package examples.datetime;

import java.time.*;

public class ZondedDateTimeApp {

   public static void main(String[] args) {
      ZoneId londonZone = ZoneId.of("Europe/London");
      
      ZonedDateTime nowBrussels = ZonedDateTime.now();
      ZonedDateTime nowLondon = ZonedDateTime.now(londonZone);
      
      System.out.println(nowBrussels);
      System.out.println(nowLondon);
   }
}
