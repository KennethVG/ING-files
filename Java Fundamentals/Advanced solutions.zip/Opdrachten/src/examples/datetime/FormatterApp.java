package examples.datetime;

import java.time.*;
import java.time.format.*;

public class FormatterApp {

   public static void main(String[] args) {
      DateTimeFormatter myFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
      DateTimeFormatter isoFormatter = DateTimeFormatter.ISO_LOCAL_DATE_TIME;

      LocalDateTime dt = LocalDateTime.parse("03/08/1998 13:45:23",
                                             myFormatter);

      System.out.println(myFormatter.format(dt));
      System.out.println(isoFormatter.format(dt));

      System.out.format("%1$td/%1$tm/%1$tY %1$tH:%1$tM:%1$tS", dt);

   }
}
