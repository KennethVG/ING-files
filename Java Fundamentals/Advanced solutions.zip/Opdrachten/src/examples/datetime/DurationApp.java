package examples.datetime;

import java.time.*;
import java.time.temporal.*;

public class DurationApp {
   public static void main(String[] args) {
      Instant now = Instant.now();
      Instant later = now.plusSeconds(500).plusMillis(2125698).plusNanos(456398);      
      
      Duration duration = Duration.between(now, later);
      System.out.println(duration.getSeconds());
      
      long milliseconds = ChronoUnit.MILLIS.between(now,later);
      
      System.out.println(milliseconds);
      
      LocalDate nowDate = LocalDate.now();
      LocalDate thenDate = LocalDate.of(1980, 2, 15);
      
      Period period = Period.between(nowDate, thenDate);
      System.out.println(period.getDays());
   }
}
