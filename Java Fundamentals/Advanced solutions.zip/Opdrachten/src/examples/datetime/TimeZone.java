package examples.datetime;

import java.time.*;

public class TimeZone {

   public static void main(String[] args) {
      ZoneId zoneId = ZoneId.of("Europe/Brussels");
      System.out.println(zoneId);
      
      ZoneId systemZoneId = ZoneId.systemDefault();
      System.out.println(systemZoneId);
      
      ZoneOffset timeZone = ZoneOffset.ofHours(2);
      System.out.println(timeZone);
   }
}
