package examples.concurrency;

import java.util.*;

public class ConcurrentListApp {
	   
   public static void main(String[] args) throws InterruptedException {
      List<Integer> list = new ArrayList<>();
      
      List<Integer> slist = Collections.synchronizedList(list);
            
		Thread thread1 = new Thread(() -> populate(slist,100));
		Thread thread2 = new Thread(() -> populate(slist,100));
		thread1.start();
		thread2.start();
		thread1.join();
		thread2.join();
		System.out.println(list.size());
	}
	
	public static void populate(List<Integer> list, int count) {
	   for(int i = 0 ; i< count; i++) {
	      list.add(i);
	   }
	}
}
