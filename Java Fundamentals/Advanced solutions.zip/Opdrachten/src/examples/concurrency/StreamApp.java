package examples.concurrency;

import java.util.*;
import java.util.function.*;
import java.util.stream.*;

public class StreamApp {

   public static void main(String[] args) {
      List<String> words = new ArrayList<>();
      words.add("Hello");
      words.add("this");
      words.add("is");
      words.add("an");
      words.add("example");
      words.add("of");
      words.add("streams");

      System.out.println("Consume: print all words");
      words.stream().forEach(System.out::println);

      System.out.println("Filter: print words with 'e'");
      Predicate<String> predicate = s -> s.contains("e");
      Stream<String> filteredStream = words.stream()
                                           .filter(predicate);
      filteredStream.forEach(System.out::println);

      System.out.println("Filter: print small words with 'e'");
      words.stream().filter(s -> s.length() > 3)
           .filter(s -> s.contains("e"))
           .forEach(System.out::println);

      System.out.println("Filter with conversion: print lenghts");
      words.stream().mapToInt(String::length)
           .forEach(System.out::println);

      System.out.println("Filter: print words uppercase");
      words.stream().map(String::toUpperCase)
           .forEach(System.out::println);

      System.out.println("Reduce: print sum of lengths");
      int length = words.stream().mapToInt(String::length).sum();
      System.out.println(length);

      System.out.println("Reduce: shortest word");
      OptionalInt min = words.stream().mapToInt(String::length)
                             .min();
      if (min.isPresent()) {
         System.out.println(min.getAsInt());
      }

      System.out.println("Reduce: print longest word");
      OptionalInt max = words.stream().mapToInt(String::length)
                             .max();
      if (max.isPresent()) {
         System.out.println(max.getAsInt());
      }

      System.out.println("Reduce: print average length of words");
      OptionalDouble avg = words.stream().mapToInt(String::length)
                                .average();
      if (avg.isPresent()) {
         System.out.println(avg.getAsDouble());
      }

      System.out.println("Reduce: print concatenated words");
      String total = words.stream()
                          .reduce("", (String r, String w) -> r + w);
      System.out.println(total);

      System.out.println("Collect: print short words as list");
      List<String> shortWords = words.stream()
                                     .filter(s -> s.length() < 3)
                                     .collect(Collectors.toList());
      shortWords.stream().forEach(System.out::println);
   }
}
