package examples.concurrency;

import java.util.*;
import java.util.concurrent.*;

public class ConcurrentListApp2 {
	   
   public static void main(String[] args) throws InterruptedException {
      List<Integer> list = new CopyOnWriteArrayList<>();
            
		Thread thread1 = new Thread(() -> populate(list,100));
		Thread thread2 = new Thread(() -> populate(list,100));
		thread1.start();
		thread2.start();
		thread1.join();
		thread2.join();
		System.out.println(list.size());
	}
	
	public static void populate(List<Integer> list, int count) {
	   for(int i = 0 ; i< count; i++) {
	      list.add(i);
	   }
	}
}
