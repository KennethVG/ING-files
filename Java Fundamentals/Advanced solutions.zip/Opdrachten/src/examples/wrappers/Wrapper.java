package examples.wrappers;

public class Wrapper {

   public static void main(String[] args) {
      Integer value1 = new Integer(5);
      Integer value2 = new Integer(5);
      System.out.println(value1 == value2);       // false
      System.out.println(value1.equals(value2));  // true    
   }
}
