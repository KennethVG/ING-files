package examples.methods;

public class Methods {
   public static void main(String[] args) {
      int n1 = SumUtility.readNumber();
      int n2 = SumUtility.readNumber();
      int s = SumUtility.sum(n1,n2);
      SumUtility.printSum(s);      
   }   
}
