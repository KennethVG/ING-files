package examples.operators;

public class PriorityApp {
   public static void main(String[] args) {
      int a = 1;
      int b = 2;
//      int result = ++a * b-- + b < 2 ? --a : ++b;
//      System.out.println(result);
      
      System.out.println(a++ + ++a);
      System.out.println(a==2? a++ : a++);
      
      
   }
}
