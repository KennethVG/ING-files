package examples.inner;

public class Outer {
   public Object getInner() {
      int a = 5;
      class Inner {
         public String toString() {
            //a++;
            return "Inner " + a;
         }
      }
      return new Inner();
   }
}
