package examples.inner;

public class App {

   public static void main(String[] args) {
      Outer out = new Outer();
      System.out.println(out.getInner());
   }
}
