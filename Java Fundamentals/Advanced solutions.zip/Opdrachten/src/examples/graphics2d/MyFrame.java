package examples.graphics2d;

import javax.swing.*;

public class MyFrame extends JFrame {
   private MyController controller;
   private MyComponent myComponent;

   public MyFrame(MyController controller) {
      super("My Application");
      this.controller = controller;
      initComponents();
      layoutComponents();
      setVisible(true);
   }

   public MyComponent getMyComponent() {
      return myComponent;
   }
   
   private void initComponents() {
      myComponent = new MyComponent();
      setDefaultCloseOperation(EXIT_ON_CLOSE);
      setSize(300, 200);
      setLocation(20, 20);
   }

   private void layoutComponents() {
      add(myComponent);
   }

}
