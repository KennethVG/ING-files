package examples.graphics2d;

public class MyApplication {
   public static void main(String[] args) {
      new MyController();
   }
}
