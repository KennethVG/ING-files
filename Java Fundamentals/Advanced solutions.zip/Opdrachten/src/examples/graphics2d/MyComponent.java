package examples.graphics2d;

import java.awt.*;
import javax.swing.JComponent;

public class MyComponent extends JComponent {

   public void paintComponent(Graphics g) {
      Graphics2D g2 = (Graphics2D) g;
      g2.rotate(Math.PI/8);
      g2.draw3DRect(100, 10, 70, 30,true);
   }

}
