package examples.gridbaglayout;

import java.awt.*;

import javax.swing.*;

public class MyFrame extends JFrame {
   private JButton button1;
   private JButton button2;
   private JButton button3;
   private JButton button4;
   private JButton button5;
   private JButton button6;
   private JButton button7;
   private JButton button8;
   private JButton button9;
   private JButton button10;
  

   public MyFrame() {
      super("GridBagLayout");
      initComponents();
      layoutComponents();
      setVisible(true);
   }

   private void initComponents() {
      button1 = new JButton("Button 1");
      button2 = new JButton("Button 2");
      button3 = new JButton("Button 3");
      button4 = new JButton("Button 4");
      button5 = new JButton("Button 5");
      button6 = new JButton("Button 6");
      button7 = new JButton("Button 7");
      button8 = new JButton("Button 8");
      button9 = new JButton("Button 9");
      button10 = new JButton("Button 10");

      setDefaultCloseOperation(EXIT_ON_CLOSE);
      setSize(400, 300);
      setLocation(20, 20);
   }
   
   private void layoutComponents() {
      GridBagConstraints c = new GridBagConstraints();
      setLayout(new GridBagLayout());

      /******************************************
       * Algemene instelling van de constraints *
       ******************************************/
      // Iedere component vult zijn vak volledig
      c.fill = GridBagConstraints.BOTH;
      // Iedere component wordt geplaatst na de vorige component
      c.gridx = GridBagConstraints.RELATIVE;
      c.gridy = GridBagConstraints.RELATIVE;
      // Iedere component wordt in het midden
      // van zijn vak geplaatst
      c.anchor = GridBagConstraints.CENTER;

      /******************
       * Knop 1 - 2 - 3 *
       *****************/
      // Allemaal hetzelfde gewicht in de X-richting zodat ze
      // gelijk verdeeld worden.
      c.weightx = 1.0;
      // Geen gewicht in de Y-richting zodat ze geen extra ruimte
      // krijgen.
      c.weighty = 0;
      // Een vak breed en een rij hoog
      c.gridwidth = 1;
      c.gridheight = 1;
      add(button1, c);
      add(button2, c);
      add(button3, c);

      /**********
       * Knop 4 *
       *********/
      // De laatste kolom
      c.gridwidth = GridBagConstraints.REMAINDER;
      add(button4, c);

      /**********
       * Knop 5 *
       *********/
      // Geen gewicht in de X-richting
      c.weightx = 0;
      // Een kolom breed
      c.gridwidth = 1;
      add(button5, c);

      /**********
       * Knop 6 *
       *********/
      // De voorlaatste kolom : zo breed als de overgebleven
      // kolommen min de laatste kolom
      c.gridwidth = GridBagConstraints.RELATIVE;
      add(button6, c);

      /**********
       * Knop 7 *
       *********/
      // De laatste kolom : zo breed als de laatste kolom
      c.gridwidth = GridBagConstraints.REMAINDER;
      add(button7, c);

      /**********
       * Knop 8 *
       *********/
      // Een kolom breed en twee rijen hoog
      c.gridheight = 2;
      c.gridwidth = 1;
      // Groot gewicht in de Y-richting zodat de grootte kan
      // veranderen
      c.weighty = 1.0;
      add(button8, c);

      /**********
       * Knop 9 *
       *********/
      // De rest van de kolommen breed en ��n rij hoog
      c.gridwidth = GridBagConstraints.REMAINDER;
      c.gridheight = 1;
      // Geen gewicht in de Y-richting
      c.weighty = 0;
      add(button9, c);

      /***********
       * Knop 10 *
       **********/
      // De rest van de kolommen breed en de rest van de rijen hoog
      c.gridwidth = GridBagConstraints.REMAINDER;
      c.gridheight = GridBagConstraints.REMAINDER;
      add(button10, c);
   }
}