package examples.autoboxing;

public class AutoboxingSuperClass {

   public static void main(String[] args) {
      Number n=5;
      Object o=6;
      System.out.println(n);
      System.out.println(o);
   }
}
