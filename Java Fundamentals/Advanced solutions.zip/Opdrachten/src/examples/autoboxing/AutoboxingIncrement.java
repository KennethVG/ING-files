package examples.autoboxing;

public class AutoboxingIncrement {
	public static void main(String[] args) {
		Integer i = 5;
		i++;
		System.out.println(i);
	}
}
