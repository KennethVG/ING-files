package examples.autoboxing;

public class AutoboxingCast {

   public static void main(String[] args) {
      System.out.println(((Integer)5).hashCode());
   }
}
