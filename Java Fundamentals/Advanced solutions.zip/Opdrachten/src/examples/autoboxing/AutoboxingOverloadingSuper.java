package examples.autoboxing;

public class AutoboxingOverloadingSuper {

	public static void main(String[] args) {
		method(5);
	}

	private static void method(Object i) {
      System.out.println("Object");
   }
	
	private static void method(Number i) {
		System.out.println("Number");
	}
}
