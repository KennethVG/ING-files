package examples.autoboxing;

public class AutoboxingWidening {

	public static void main(String[] args) {
		int a = 5;
		//method(a);
	}

	private static void method(Long l) {
		System.out.println("Long");
	}
	
}
