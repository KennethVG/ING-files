package examples.autoboxing;

public class AutoBoxing {

   public static void main(String[] args) {
      Integer intObject = 5;
      int intPrimitive = new Integer(6);
      System.out.println(intObject);
      System.out.println(intPrimitive);      
   }
}
