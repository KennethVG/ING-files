package examples.autoboxing;

public class AutoboxingOverloading {

	public static void main(String[] args) {
		method(5);
	}

	private static void method(long i) {
		System.out.println("long");
	}
	
	private static void method(Integer i) {
		System.out.println("Integer");
	}
}
