package examples.autoboxing;

public class BadAutoboxing {
   public static void main(String[] args) {
      Integer a = 5;
      Integer b = 6;
      Integer c = a+b;
      System.out.println(c);      
   }   
}
