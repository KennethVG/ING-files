package examples.cipher;

import java.io.*;

public class CipherOutputStream extends FilterOutputStream {
	private byte key;

	public CipherOutputStream(OutputStream out) {
		super(out);
	}

	public void setKey(byte key) {
		this.key = key;
	}
	
	public void write(int c) throws IOException {
		out.write(cipher((byte) c));
	}
	
	private byte cipher(byte data) {
		return (byte) (data ^ key);
	}
}
