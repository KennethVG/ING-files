package examples.cipher;

import java.io.*;

public class CipherWriteApp {
   public static void main(String[] args) {
      try (FileOutputStream fos = new FileOutputStream("cipher.txt");
            CipherOutputStream cipherStream = new CipherOutputStream(fos);
            PrintWriter destination = new PrintWriter(cipherStream);) {
         cipherStream.setKey((byte) 123);
         destination.println("This message will be encrypted!");
      } catch (IOException ex) {
         System.out.println(ex.getMessage());
      }
   }
}
