package examples.cipher;

import java.io.*;

public class CipherInputStream extends FilterInputStream {
	private byte key;

	public CipherInputStream(InputStream in) {
		super(in);
	}

	public void setKey(byte key) {
		this.key = key;
	}

	public int read()throws IOException {
		int ret = in.read();
		if (ret != -1) {
			ret = cipher((byte)ret);
		}
		return ret;
	}
	
	public int read(byte[] buffer, int off, int len)
			throws IOException {
		int ret = in.read(buffer, off, len);
		if (ret != -1) {
			for (int i = off; i < off + len; i++) {
				buffer[i] = cipher(buffer[i]);
			}
		}
		return ret;
	}

	private byte cipher(byte data) {
		return (byte) (data ^ key);
	}
}
