package examples.cipher;

import java.io.*;

public class CipherReadApp {
   public static void main(String[] args) {
      try (FileInputStream file = new FileInputStream("cipher.txt");
            CipherInputStream cipherStream = new CipherInputStream(file);
            InputStreamReader inputstream = new InputStreamReader(cipherStream);
            LineNumberReader source = new LineNumberReader(inputstream);) {
         cipherStream.setKey((byte) 123);
         String text;
         while ((text = source.readLine()) != null) {
            System.out.println(text);
         }
      } catch (IOException ex) {
         System.out.println(ex.getMessage());
      }
   }
}
