package examples.calculator;

public class CalculateThread extends Thread {
	private long number;
	private Calculator calc;
	public CalculateThread(Calculator calc, long number)	{
		this.number = number;
		this.calc = calc;
	}

	public void run()	{
		for(long i= 0; i < number;i++)	{
			int value = (int) Math.round(Math.random() * 10);
         calc.setValue(value);     
                  
         int result = calc.getResult();
         System.out.println(value + " : " + result);
			if(result != (value * value))
			   System.out.println("Fout");
		}
	}
}
