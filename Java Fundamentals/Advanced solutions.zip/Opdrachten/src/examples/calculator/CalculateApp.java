package examples.calculator;

public class CalculateApp {
	public static void main(String[] args) {
		Calculator calc = new Calculator();

      CalculateThread thread1 = new CalculateThread(calc, 100);
      CalculateThread thread2 = new CalculateThread(calc, 100);
      CalculateThread thread3 = new CalculateThread(calc, 100);
		thread1.start();
		thread2.start();
		thread3.start();
	}
}
