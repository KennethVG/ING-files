package examples.calculator;

public class Calculator extends Thread {
   private int value = 0;
   private int result = 0;
   private boolean done = true;
   private boolean busy = false;

   public Calculator() {
      setDaemon(true);
      start();
   }

   public synchronized void setValue(int value) {
      while (busy) {
         try {
            wait();
         } catch (InterruptedException e) {
         }
      }
      this.value = value;
      done = false;
      busy = true;
      notifyAll();
   }

   public synchronized int getResult() {
      while (!done) { // Wachten tot de berekening gedaan is
         try {
            wait();
         } catch (InterruptedException e) {
         }
      }
      busy = false;
      notifyAll();
      return result;
   }

   public synchronized void run() {
      while (true) { // Oneindige lus
         while (done) { // Wacht tot er iets te berekenen is
            try {
               wait();
            } catch (InterruptedException e) {
            }
         }
         result = value * value; // Bereken het resultaat
         done = true;
         notifyAll();
      }
   }
}
