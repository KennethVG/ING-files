package examples.map;

import java.util.*;

public class MapApplication {
   public static void main(String[] args) {

      Map<String,Integer> ingredients = new HashMap<>();
      ingredients.put("Potatoes",5);
      ingredients.put("Carrots",4);
      ingredients.put("Beans",2);
      ingredients.put("Chicken", 1);
      
      System.out.println(ingredients.get("Chicken"));

      for(String s: ingredients.keySet()) {
         System.out.println(s + ": " + ingredients.get(s));
      }
      
      ingredients.forEach((k,v)-> System.out.println(k+": "+v));
      
   }

}
