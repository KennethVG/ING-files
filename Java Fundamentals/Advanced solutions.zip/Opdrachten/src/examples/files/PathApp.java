package examples.files;

import java.nio.file.*;

public class PathApp {

   public static void main(String[] args) throws Exception{
      FileSystem fs = FileSystems.getDefault();
      Path path = Paths.get("C:\\data\\subfolder1\\file1.txt");
      
      System.out.println(path.getRoot());
      System.out.println(path.getFileName());
      System.out.println(path.getParent());
      for(Path p: path) {
         System.out.println(p);
      }
      
      Path p1 = Paths.get("C:\\data");
      Path p2 = p1.resolve("folder1");
      Path p3 = p2.resolve("file1.txt");

      System.out.println(p3);
      
      Path real = p3.toRealPath();
      System.out.println(real);

      Path p4 = Paths.get("file2.txt");
      System.out.println(p4.toAbsolutePath());
      
      Path p5 = Paths.get("C:\\data\\subfolder1\\file1.txt");
      Path p6 = Paths.get("C:\\data\\subfolder2\\file3.txt");
      Path p7 = p5.relativize(p6);
      System.out.println(p7);

   }
}
