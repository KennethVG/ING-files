package examples.files;

import java.io.*;
import java.nio.file.*;

public class FileSystemApp {
   public static void main(String[] args) {
      try (FileSystem fs = FileSystems.getDefault()) {
         System.out.println(fs.getSeparator());
         for (Path p : fs.getRootDirectories()) {
            System.out.println(p);
         }
      } catch (IOException e) {
         e.printStackTrace();
      }
   }
}
