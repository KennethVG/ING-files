package examples.files;

import java.io.*;
import java.nio.charset.*;
import java.nio.file.*;
import java.nio.file.attribute.*;
import java.util.*;

public class FilesApp {

   public static void main(String[] args) {
      try {
         // Define Path
         Path path = Paths.get("C:\\data\\folder\\file.txt");
         // Create parent directories
         Files.createDirectories(path.getParent());
         // Create if not exists
         if(Files.notExists(path)) {
            Files.createFile(path);
            System.out.println("File created");
         } else {
            System.out.println("File already exsts.");
         }
         
         // Write lines of text to file
         List<String> lines = new ArrayList<>();
         lines.add("Hello");
         lines.add("World");         
         Files.write(path, lines, Charset.defaultCharset(),StandardOpenOption.APPEND);
                  
         // Retrieve attributes of file
         DosFileAttributes attrs= Files.readAttributes(path, DosFileAttributes.class);
         System.out.println(attrs.size());
         System.out.println(attrs.creationTime());
         System.out.println(attrs.lastAccessTime());
         System.out.println(attrs.lastModifiedTime());
         System.out.println(attrs.isArchive());
         System.out.println(attrs.isHidden());
         System.out.println(attrs.isReadOnly());    
         
         // Read lines of text from file
         lines = Files.readAllLines(path, Charset.defaultCharset());
         for(String l: lines) {
            System.out.println(l);
         }
         
         Files.lines(path).forEach(System.out::println);
         
         // Copy file
         Path path2 = Paths.get("C:\\data\\folder\\file_copy.txt");
         Files.copy(path, path2, StandardCopyOption.REPLACE_EXISTING);
         
         // Delete file
         Files.deleteIfExists(path);
         
      } catch (IOException e) {
         e.printStackTrace();
      }
   }
}
