package examples.actionlistener.controller;

import java.awt.BorderLayout;
import javax.swing.*;

public class MyFrame extends JFrame {
   private MyController controller;
   private JTextArea textArea;
   private JButton button;

   public MyFrame(MyController controller) {
      super("ActionListener");
      this.controller = controller;
      initComponents();
      layoutComponents();
      initListeners();
      setVisible(true);
   }

   private void initComponents() {
      button = new JButton("Add text");
      textArea = new JTextArea();

      setDefaultCloseOperation(EXIT_ON_CLOSE);
      setSize(300, 200);
      setLocation(20, 20);
   }

   private void layoutComponents() {
      add(button, BorderLayout.SOUTH);
      add(textArea, BorderLayout.CENTER);
   }

   private void initListeners() {
      button.addActionListener(e -> controller.buttonClicked());
   }

   public JTextArea getTextArea() {
      return textArea;
   }
}
