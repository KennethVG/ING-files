package examples.actionlistener.controller;


public class MyController {
   private MyFrame view;
   
   public MyController() {
      init();
   }
   
   private void init() {
      view = new MyFrame(this);
   }
   
   public void buttonClicked() {
      view.getTextArea().append("Button pressed\n");     
      // Communicatie with model
   }
   
}
