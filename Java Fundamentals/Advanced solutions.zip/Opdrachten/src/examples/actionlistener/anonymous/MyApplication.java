package examples.actionlistener.anonymous;

import examples.actionlistener.MyFrame;

public class MyApplication{
   public static void main(String[] args) {
      new MyFrame();
   }
}
