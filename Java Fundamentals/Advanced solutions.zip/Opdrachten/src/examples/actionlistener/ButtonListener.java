package examples.actionlistener;

import java.awt.event.*;

import javax.swing.*;

public class ButtonListener implements ActionListener {
   private JTextArea text;

   public ButtonListener(JTextArea text) {
      this.text = text;
   }

   public void actionPerformed(ActionEvent e) {
      text.append("Button pressed\n");
   }
}
