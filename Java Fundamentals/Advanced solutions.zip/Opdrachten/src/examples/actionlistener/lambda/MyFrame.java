package examples.actionlistener.lambda;

import java.awt.*;

import javax.swing.*;

public class MyFrame extends JFrame {
   private JButton button;
   private JTextArea textArea;
   
   public MyFrame() {
      super("ActionListener");
      initComponents();
      layoutComponents();
      initListeners();
      setVisible(true);
   }

   private void initComponents() {
      button = new JButton("Add text");
      textArea = new JTextArea();

      setDefaultCloseOperation(EXIT_ON_CLOSE);
      setSize(300, 200);
      setLocation(20, 20);
   }

   private void layoutComponents() {
      add(button, BorderLayout.SOUTH);
      add(textArea, BorderLayout.CENTER);
   }

   private void initListeners() {
      button.addActionListener(e -> textArea.append("Button pressed\n") );
   }
}

