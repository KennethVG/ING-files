package examples.actionlistener.nested;
import javax.swing.*;
import examples.actionlistener.MyFrame;

public class MyApplication extends JFrame {

   public static void main(String[] args) {
      new MyFrame();
   }
}
