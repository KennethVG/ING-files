package examples.javafx.stylesheets;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.*;
import javafx.stage.Stage;

public class StyleSheetsApp extends Application {
   public static void main(String[] args) {
      launch(args);
   }

   @Override
   public void start(Stage stage) throws Exception {
      Parent root = FXMLLoader.load(getClass().getResource(
         "StyleSheets.fxml"));
      Scene scene = new Scene(root, 300, 200);
      stage.setTitle("StyleSheets");
      stage.setScene(scene);
      stage.show();
   }
}
