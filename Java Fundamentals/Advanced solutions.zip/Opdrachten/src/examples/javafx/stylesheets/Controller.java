package examples.javafx.stylesheets;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;

public class Controller {
   @FXML
   private TextField textField;

   @FXML
   private void buttonPressed(ActionEvent ev) {
      if (textField.getText().isEmpty()) {
         textField.getStyleClass().add("error");
      } else {
         textField.getStyleClass().remove("error");         
      }
   }
}
