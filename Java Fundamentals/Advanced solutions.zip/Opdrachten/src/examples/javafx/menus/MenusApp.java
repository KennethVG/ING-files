package examples.javafx.menus;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.*;
import javafx.stage.Stage;

public class MenusApp extends Application {

   public static void main(String[] args) {
      launch(args);
   }

   @Override
   public void start(Stage stage) throws Exception {
      Parent root = FXMLLoader.load(getClass().getResource(
         "Menu.fxml"));
      Scene scene = new Scene(root, 300, 300);
      stage.setTitle("Menus");      
      stage.setScene(scene);
      stage.show();
   }
}
