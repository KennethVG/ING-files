package examples.javafx.events;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.*;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class EventsApp extends Application {

   public static void main(String[] args) {
      launch(args);
   }

   @Override
   public void start(Stage stage) throws Exception {
      Label l;
      Parent root = FXMLLoader.load(getClass().getResource(
         "Events.fxml"));
      Scene scene = new Scene(root, 300, 200);
      stage.setTitle("Events");      
      stage.setScene(scene);
      stage.show();
   }
   
   
}
