package examples.javafx.events;

import javafx.fxml.FXML;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;

public class MouseEventsController {
   @FXML
   private Text text;
   
   @FXML
   private void mouseMoved(MouseEvent ev) {
      text.setText(String.format("Mouse moved (%.0f,%.0f)", ev.getX(),ev.getY()));
   }
   
}
