package examples.javafx.dialogs;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.*;
import javafx.stage.Stage;

public class DialogsApp extends Application {
   public static void main(String[] args) {
      launch(args);
   }

   @Override
   public void start(Stage stage) throws Exception {
      Parent root = FXMLLoader.load(getClass().getResource("Dialogs.fxml"));
      Scene scene = new Scene(root, 300, 100);
      stage.setTitle("Dialogs");
      stage.setScene(scene);
      stage.show();
   }
}
