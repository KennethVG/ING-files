package examples.javafx.dialogs;
import java.io.File;
import java.util.Optional;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.Pane;
import javafx.stage.FileChooser;

public class Controller {
   @FXML
   private Pane pane;

   @FXML
   private Alert alert;
   
   @FXML
   private TextInputDialog dialog;
   
   @FXML
   private FileChooser fileChooser;
   
   @FXML
   private void showAlert(ActionEvent ev) {
//      Alert alert = new Alert(AlertType.CONFIRMATION);
//      alert.setTitle("This is the title");
//      alert.setHeaderText("This is the header");
//      alert.setContentText("This is the content");
      Optional<ButtonType> result = alert.showAndWait();
      if (result.isPresent()) {
         ButtonType button = result.get();
      }
   }

   @FXML
   private void showTextInputDialog(ActionEvent ev) {
//      TextInputDialog dialog = new TextInputDialog();
//      dialog.setTitle("Title");
//      dialog.setHeaderText("Header");
//      dialog.setContentText("Content");
      dialog.showAndWait();
      String result = dialog.getResult();
   }

   @FXML
   private void showFileChooser(ActionEvent ev) {
//      FileChooser fileChooser = new FileChooser();
//      fileChooser.setTitle("Select a file");
      File file = fileChooser.showOpenDialog(pane.getScene()
         .getWindow());
      String path = file.getAbsolutePath();
   }
   
}
