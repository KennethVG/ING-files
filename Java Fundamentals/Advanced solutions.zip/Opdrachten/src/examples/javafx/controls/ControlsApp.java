package examples.javafx.controls;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.*;
import javafx.stage.Stage;

public class ControlsApp extends Application {
   public static void main(String[] args) {
      launch(args);
   }

   @Override
   public void start(Stage stage) throws Exception {
      Parent root = FXMLLoader.load(getClass().getResource(
         "ColorPicker.fxml"));
      Scene scene = new Scene(root, 300, 200);
      stage.setTitle("Controls");
      stage.setScene(scene);
      stage.show();
   }
}
