package examples.algorithms.sequence;

public class Sum {
   public static void main(String[] args) {
      int a = 5;
      int b = 6;
      int sum = a + b;
   }
}
