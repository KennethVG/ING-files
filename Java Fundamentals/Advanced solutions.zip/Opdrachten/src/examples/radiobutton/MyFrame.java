package examples.radiobutton;

import java.awt.*;

import javax.swing.*;

public class MyFrame extends JFrame {

   public MyFrame() {
      super("My Application");
      initComponents();
      setVisible(true);

   }

   private void initComponents() {
      setLayout(new FlowLayout());

      JRadioButton smallButton = new JRadioButton("Small");
      JRadioButton mediumButton = new JRadioButton("Medium");
      JRadioButton largeButton = new JRadioButton("Large");
      ButtonGroup buttonGroup = new ButtonGroup();
      buttonGroup.add(smallButton);
      buttonGroup.add(mediumButton);
      buttonGroup.add(largeButton);
      
      add(smallButton);
      add(mediumButton);
      add(largeButton);
            
      setDefaultCloseOperation(EXIT_ON_CLOSE);
      setSize(300, 200);
      setLocation(20, 20);
   }
}