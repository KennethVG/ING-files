package examples.frame;

import javax.swing.*;

public class MyFrame extends JFrame {

   public MyFrame() {
      super("My Application");
      initComponents();
      setVisible(true);
   }

   private void initComponents() {
      add(new JLabel("This is my first graphical application!"));
      setDefaultCloseOperation(EXIT_ON_CLOSE);
      setSize(300, 200);
      setLocation(20, 20);
   }
}