package examples.timer;

import java.util.*;

public class TimeoutApp {
   public static void main(String[] args) {
      Timeout task = new Timeout();
      Timer timer = new Timer(true);
      timer.schedule(task,1000 * 10);

      System.out.println("Even geduld!");
      try {
         Thread.sleep(20 * 1000);
      }
      catch(InterruptedException uitzondering)  {
      }
   }
}
