package examples.timer;

import java.util.*;

public class Timeout extends TimerTask {
   public void run() {
      System.out.println("De tijd is verstreken");
   }
}
