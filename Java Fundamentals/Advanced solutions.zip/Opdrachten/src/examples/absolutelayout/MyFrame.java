package examples.absolutelayout;

import javax.swing.*;

public class MyFrame extends JFrame {
   private JButton button;

   public MyFrame() {
      super("AbsoluteLayout");
      initComponents();
      layoutComponents();
      setVisible(true);
   }

   private void initComponents() {
      button = new JButton("Button");
      setDefaultCloseOperation(EXIT_ON_CLOSE);
      setSize(300, 200);
      setLocation(20, 20);
   }
   
   private void layoutComponents() {
      setLayout(null);
      button.setBounds(50,70,120,45);
      add(button);  
   }
}