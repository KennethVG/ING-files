package examples.absolutelayout;

public class MyApplication {

   public static void main(String[] args) {
      new MyFrame();
   }
}
