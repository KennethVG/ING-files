package examples.console;

import java.io.*;

public class ConsoleTest {
   public static void main(String... args) {
      Console console = System.console();
      if (console == null) {
         System.out.println("No console available!");
         return;
      }
      
      String name = console.readLine("Name: ");
      console.printf("Your name is %s \n",name);
      char[] password = console.readPassword("Password: ");
      console.printf("Your password is %s",new String(password));
   }
}
