package examples.properties;
import java.io.*;
import java.util.*;

public class WriteProperties {
   public static void main(String[] args) {
      try (FileOutputStream out = new FileOutputStream(
         "Application.xml");) {
         Properties atts = new Properties();
         atts.setProperty("Attribute1", "Value1");
         atts.setProperty("Attribute2", "Value2");
         atts.setProperty("Attribute3", "Value3");
         atts.storeToXML(out, "Application Properties");
      } catch (Exception ex) {
         System.out.println(ex.getMessage());
      }
   }
}
