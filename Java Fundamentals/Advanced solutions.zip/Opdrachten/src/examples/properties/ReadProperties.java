package examples.properties;

import java.io.*;
import java.util.*;

public class ReadProperties {
   public static void main(String[] args) {
      try (FileInputStream in = 
            new FileInputStream("Application.properties");) {
         Properties atts = new Properties();
         atts.load(in);
         atts.list(System.out);
      }
      catch(Exception ex) {
         System.out.println(ex.getMessage());
      }
   }
}