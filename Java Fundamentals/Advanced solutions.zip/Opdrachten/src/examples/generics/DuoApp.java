package examples.generics;

public class DuoApp {
   @SuppressWarnings("rawtypes")
   public static void main(String[] args) {
      Duo<String>  sd = new Duo<>("Hello","World");
      Duo<Integer> id = new Duo<>(7,5);                  
      Duo<Long>    ld = new Duo<>(746987L,546358L);                        
      Duo<Float>   fd = new Duo<>(5.7F,8.9F);
      
      Duo<Integer> id1 = new Duo<>(3,5);
      Duo<Integer> id2 = new Duo<>(7,8);      
      
      Duo<String> sd1 = new Duo<>("ABC","DEF");
      Duo<String> sd2 = new Duo<>("GHI","JKL");      
      
      Duo od = new Duo("ABC","DEF");
      
      swapDuo(id1,id2);
      swapDuo(sd1,sd2);
      
      printDuo(id1);
      printDuo(id2);
      
      
      String s1 = sd.getFirst();
      String s2 = sd.getSecond();
     
      
      
      Integer i1 = id.getFirst(); 
      Integer i2 = id.getSecond(); 
      
      System.out.println(s1 + " " + s2);
      System.out.println(i1 + i2);
      
      printDuo(sd);
      printDuo(id);
      
      printSum(id);
      printSum(ld);
      printSum(fd);
      
      printSum(id1,id2);
      
      Duo<Number> nd = new Duo<Number>(4,5);
      
      
      Duo<?>[] duos = new Duo<?>[5];

     
      
      Object[] objects = (Object[]) duos;
      objects[0] = new Duo<Double>(5D,7D);
      
      
      if(id instanceof Duo) System.out.println("ok");
   }   
   
   public static void printDuo(Duo<?> d) {
      System.out.println(d.getFirst() +"," +d.getSecond());
   }
   
   public static void printSum(Duo<? extends Number> d) {
      Number n1 = d.getFirst();
      Number n2 = d.getSecond();
      System.out.println(n1+"+"+n2+"="+(n1.doubleValue()+n2.doubleValue()));
   }
   
   public static <T extends Number> void printSum(Duo<T> d1, Duo<T> d2) {
      Number n1 = d1.getFirst();
      Number n2 = d1.getSecond();
      Number n3 = d2.getFirst();
      Number n4 = d2.getSecond();
      
      System.out.println(n1.doubleValue()+n2.doubleValue()+n3.doubleValue()+n4.doubleValue());
   }
   
   public static <T> void swapDuo(Duo<T> d1, Duo<T> d2) {
      T temp = d1.getFirst();
      d1.setFirst(d2.getFirst());
      d2.setFirst(temp);
   }
   
   public static <T> T getHighest(Duo<T> d1, Duo<T> d2) {
   	return d1.getFirst();
   }
   
}
