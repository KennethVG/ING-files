package examples.generics;


public class IntegerDuoApp {
   public static void main(String[] args) {
      IntegerDuo id = new IntegerDuo(4,5);
      System.out.println(id.getFirst());
      System.out.println(id.getSecond());
   }
}
