package examples.generics;

public class Shoe {

}
