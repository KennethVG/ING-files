package examples.generics;

public class IntegerDuo extends Duo<Integer> {

   public IntegerDuo(Integer first, Integer second) {
      super(first, second);
   }

}
