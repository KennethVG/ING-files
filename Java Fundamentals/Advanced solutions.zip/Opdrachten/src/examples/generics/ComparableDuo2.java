package examples.generics;

public class ComparableDuo2<E extends Number & Comparable<E>> extends Duo<E>{

   public ComparableDuo2(E first, E second) {
      super(first, second);
   }
}
