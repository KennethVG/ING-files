package examples.generics;

public class MyDuo<E> extends Duo<E> {

   public MyDuo(E first, E second) {
      super(first, second);
   }

}
