package examples.generics.legacy;

public class Duo {
   private Object first;
   private Object second;
      
   public Duo(Object first, Object second) {
      this.first = first;
      this.second = second;
   }
   
   public void setFirst(Object first){
      this.first = first;
   }
   
   public void setSecond(Object second){
      this.second = second;
   }
   
   public Object getFirst() {
      return first;
   }
   
   public Object getSecond() {
      return second;
   }   
}
