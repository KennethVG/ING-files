package examples.formatter;

import java.util.*;

public class Format {
   public static void main(String[] args) {
      StringBuilder text = new StringBuilder();
      Formatter formatter = new Formatter(text);
      formatter.format("%-6d %06d %.2f",-125,145,123.56987);
      System.out.println(text);      
      System.out.format("%-6d %06d %.2f",-125,145,123.56987);
      formatter.close();
    }
}
