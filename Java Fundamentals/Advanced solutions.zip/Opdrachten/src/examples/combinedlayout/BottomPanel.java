package examples.combinedlayout;

import java.awt.*;

import javax.swing.*;

public class BottomPanel extends JPanel {
   private JButton button4;
   private JButton button5;
   private JButton button6;
   
   public BottomPanel() {
      initComponents();   
      layoutComponents();
   }
   
   private void initComponents() {
      button4 = new JButton("Button 4");
      button5 = new JButton("Button 5");
      button6 = new JButton("Button 6");
   }
   
   private void layoutComponents() {
      setLayout(new FlowLayout());
      add(button4);
      add(button5);
      add(button6);      
   }

}
