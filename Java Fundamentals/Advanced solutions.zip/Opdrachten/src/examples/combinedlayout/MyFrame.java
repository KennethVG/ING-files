package examples.combinedlayout;

import java.awt.*;

import javax.swing.*;

public class MyFrame extends JFrame {
   // private JButton button1;
   // private JButton button2;
   // private JButton button3;
   // private JButton button4;
   // private JButton button5;
   // private JButton button6;
   private JTextArea textArea;

   public MyFrame() {
      super("CombinedLayout");
      initComponents();
      layoutComponents();
      setVisible(true);
   }

   private void initComponents() {
      // button1 = new JButton("Button 1");
      // button2 = new JButton("Button 2");
      // button3 = new JButton("Button 3");
      // button4 = new JButton("Button 4");
      // button5 = new JButton("Button 5");
      // button6 = new JButton("Button 6");
      textArea = new JTextArea();

      setDefaultCloseOperation(EXIT_ON_CLOSE);
      setSize(300, 200);
      setLocation(20, 20);
   }

   private void layoutComponents() {
       JPanel bottomPanel = new BottomPanel();
       JPanel topPanel = new TopPanel();
       add(bottomPanel, BorderLayout.SOUTH);
       add(topPanel, BorderLayout.NORTH);
       add(textArea,BorderLayout.CENTER);

      // JPanel bottomPanel = new JPanel();
      // JPanel topPanel = new JPanel();
      // add(bottomPanel,BorderLayout.SOUTH);
      // add(topPanel,BorderLayout.NORTH);
      // add(textArea,BorderLayout.CENTER);
      //
      // topPanel.setLayout(new GridLayout(1,3));
      // topPanel.add(button1);
      // topPanel.add(button2);
      // topPanel.add(button3);
      //
      // bottomPanel.setLayout(new FlowLayout());
      // bottomPanel.add(button4);
      // bottomPanel.add(button5);
      // bottomPanel.add(button6);
      //
   }
}