package examples.combinedlayout;

import java.awt.*;

import javax.swing.*;

public class TopPanel extends JPanel {
   private JButton button1;
   private JButton button2;
   private JButton button3;
   
   public TopPanel() {
      initComponents();   
      layoutComponents();
   }
   
   private void initComponents() {
      button1 = new JButton("Button 1");
      button2 = new JButton("Button 2");
      button3 = new JButton("Button 3");
   }
   
   private void layoutComponents() {
      setLayout(new GridLayout(1,3));
      add(button1);
      add(button2);
      add(button3);      
   }

}
