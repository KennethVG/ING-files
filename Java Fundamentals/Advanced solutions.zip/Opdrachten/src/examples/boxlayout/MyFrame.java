package examples.boxlayout;

import javax.swing.*;

public class MyFrame extends JFrame {
   private JButton button1;
   private JButton button2;
   private JButton button3;
   private JButton button4;

   public MyFrame() {
      super("BoxLayout");
      initComponents();
      layoutComponents();
      setVisible(true);
   }

   private void initComponents() {
      button1 = new JButton("Button 1");
      button2 = new JButton("Button 2");
      button3 = new JButton("Button 3");
      button4 = new JButton("Button 4");
      
      setDefaultCloseOperation(EXIT_ON_CLOSE);
      setSize(300, 200);
      setLocation(20, 20);
   }
   
   private void layoutComponents() {
      setLayout(new BoxLayout(getContentPane(),BoxLayout.Y_AXIS));
      add(button1);
      add(button2);
      add(button3);
      add(button4);      
   }
}