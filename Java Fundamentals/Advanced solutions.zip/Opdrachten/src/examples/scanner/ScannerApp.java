package examples.scanner;

import java.util.*;

public class ScannerApp {
   public static void main(String[] args) {
      try (Scanner scanner = new Scanner(System.in)) {
         System.out.println("Please enter your name and age:");
         String name = scanner.next();
         int age = scanner.nextInt();
         System.out.printf("Hello %s, you are %d years old.", name, age);         
      }
   }
}
