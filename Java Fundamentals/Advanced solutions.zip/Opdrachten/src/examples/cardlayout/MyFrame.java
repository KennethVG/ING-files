package examples.cardlayout;
import java.awt.*;
import javax.swing.*;

public class MyFrame extends JFrame {
   private JButton button1;
   private JButton button2;
   private JButton button3;
   private JButton button4;
   private JButton button5;
   private JButton button6;
   

   public MyFrame() {
      super("CardLayout");
      initComponents();
      layoutComponents();
      setVisible(true);
   }

   private void initComponents() {
      button1 = new JButton("Button 1");
      button2 = new JButton("Button 2");
      button3 = new JButton("Button 3");
      button4 = new JButton("Button 4");
      button5 = new JButton("Button 5");
      button6 = new JButton("Button 6");
      setDefaultCloseOperation(EXIT_ON_CLOSE);
      setSize(300, 200);
      setLocation(20, 20);
   }
   
   private void layoutComponents() {
      CardLayout cardLayout = new CardLayout();
      setLayout(cardLayout);

      add(button1,"card1");
      add(button2,"card2");
      add(button3,"card3");
      add(button4,"card4");
      add(button5,"card5");
      add(button6,"card6");
      cardLayout.show(getContentPane(), "card3");
      
   }
}