package collections_07;

public enum GenderType {
   MALE,FEMALE;
}
