package eu.noelvaes.hello;

import java.net.*;

import javax.swing.*;

public class HelloWorldSwing extends JFrame {
   private JLabel label;

   public HelloWorldSwing() {
      super("Hello World");
      initComponents();
      layoutComponents();
      
   }

   private void initComponents() {
      URL url = getClass().getResource("icon.png");
      ImageIcon icon = new ImageIcon(url);
      label = new JLabel(icon);
      setDefaultCloseOperation(EXIT_ON_CLOSE);
      setSize(300, 200);
      setLocation(20, 20);
      setVisible(true);    
   }

   private void layoutComponents() {
      add(label);
   }

   public static void main(String[] args) {
      HelloWorldSwing app = new HelloWorldSwing();

   }

}
