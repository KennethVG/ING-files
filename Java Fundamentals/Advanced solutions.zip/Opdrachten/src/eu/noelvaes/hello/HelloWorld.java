package eu.noelvaes.hello;
public class HelloWorld {
   public static void main(String[] args) {
      Hello hello = new Hello();
      // System.out.println("Hello World");
      System.out.println(hello.sayHello());
   }
}
