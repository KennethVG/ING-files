package exercise05_17;

public class For2 {
    public static void main(String[] args) {
        for (int multiple = 0; multiple < 200; multiple+= 7) {
            System.out.println(multiple);
        }
    }
}