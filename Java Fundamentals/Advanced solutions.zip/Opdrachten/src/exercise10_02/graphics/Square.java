package exercise10_02.graphics;

public class Square extends Rectangle {

}
