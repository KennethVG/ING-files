package exercise10_01.graphics;

public class Square extends Rectangle {

}
