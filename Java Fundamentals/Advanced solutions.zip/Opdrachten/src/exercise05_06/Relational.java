package exercise05_06;

public class Relational {
	public static void main(String[] args) {
		int number1 = 8;
		int number2 = -6;
		System.out.println("number1: " + number1);
		System.out.println("number2: " + number2);
		System.out.println("number1 < number2    : " + (number1 < number2));
		System.out.println("number1 <= number2   : " + (number1 <= number2));
		System.out.println("number1 > number2    : " + (number1 > number2));
		System.out.println("number1 >= number2   : " + (number1 >= number2));
		System.out.println("number1 == number2   : " + (number1 == number2));
		System.out.println("number1 != number2   : " + (number1 != number2));
	}
}