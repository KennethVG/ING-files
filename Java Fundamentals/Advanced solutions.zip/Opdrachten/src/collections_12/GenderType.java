package collections_12;

public enum GenderType {
   MALE,FEMALE;
}
