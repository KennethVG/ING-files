package exercise05_07;

public class Logical {
	public static void main(String[] args) {
		boolean value1 = true;
		boolean value2 = false;

		System.out.println("value1           : " + value1);
		System.out.println("value2           : " + value2);
		System.out.println("value1 && value2 : " + (value1 && value2));
		System.out.println("value1 || value2 : " + (value1 || value2));
		System.out.println("!value1          : " + (!value1));
		System.out.println("!value2          : " + (!value2));
	}
}