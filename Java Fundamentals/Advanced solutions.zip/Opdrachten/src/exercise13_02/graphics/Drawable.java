package exercise13_02.graphics;

import javafx.scene.canvas.GraphicsContext;

public interface Drawable extends Scaleable{
	public void draw(GraphicsContext g);
}
