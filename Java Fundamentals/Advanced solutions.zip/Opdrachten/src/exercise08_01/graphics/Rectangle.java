package exercise08_01.graphics;

public class Rectangle {

}
