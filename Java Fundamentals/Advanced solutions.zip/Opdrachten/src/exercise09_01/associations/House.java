package exercise09_01.associations;

public class House {
   private Room kitchen = new Room("kitchen");
   private Room bathRoom = new Room("bathroom");
   private Room livingRoom = new Room("livingroom");
   private Room sleepingRoom = new Room("sleepinroom");

   
}
