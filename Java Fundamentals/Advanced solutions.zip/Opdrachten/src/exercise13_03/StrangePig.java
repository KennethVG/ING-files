package exercise13_03;

public class StrangePig implements Pig{
   public void grunt() {
      System.out.println("Oink");
   }
}
