package exercise13_03;

public class MyPig implements Pig {
   public void grunt() {
      System.out.println("Grunt");
   }
}
