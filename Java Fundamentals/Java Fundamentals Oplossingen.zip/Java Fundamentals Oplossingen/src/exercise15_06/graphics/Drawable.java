package exercise15_06.graphics;

import java.awt.*;

public interface Drawable extends Scaleable{
	public void draw(Graphics g);
}
