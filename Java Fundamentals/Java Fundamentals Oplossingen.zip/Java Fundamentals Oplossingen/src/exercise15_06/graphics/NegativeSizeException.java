package exercise15_06.graphics;

public class NegativeSizeException extends RuntimeException {

   public NegativeSizeException() {
      super();
   }

   public NegativeSizeException(String message, Throwable cause,
         boolean enableSuppression, boolean writableStackTrace) {
      super(message, cause, enableSuppression, writableStackTrace);
   }

   public NegativeSizeException(String message, Throwable cause) {
      super(message, cause);
   }

   public NegativeSizeException(String message) {
      super(message);
   }

   public NegativeSizeException(Throwable cause) {
      super(cause);
   }
   
}
