package streams_01;

import java.util.stream.IntStream;

public class IntStreamApp {

	public static void main(String[] args) {
		IntStream.range(0,100)
		         .forEach((e) -> System.out.println(e*e));
		
		IntStream.iterate(0, i -> ++i).forEach(System.out::println);
		
	}
}
