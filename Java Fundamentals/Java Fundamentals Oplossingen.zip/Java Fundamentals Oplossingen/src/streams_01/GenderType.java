package streams_01;

public enum GenderType {
   MALE,FEMALE;
}
