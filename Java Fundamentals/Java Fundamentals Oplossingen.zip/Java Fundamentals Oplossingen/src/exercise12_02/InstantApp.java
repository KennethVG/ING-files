package exercise12_02;

import java.time.*;
import java.util.*;

public class InstantApp {

   public static void main(String[] args) {
      Scanner keyboard = new Scanner(System.in);
      Instant before = Instant.now();
      String name = keyboard.next();
      Instant after = Instant.now();
      long duration = after.getEpochSecond() - before.getEpochSecond();
      System.out.println(duration + " seconds");
      
      
   }

}
