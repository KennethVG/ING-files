package lambda_01;

public class TextApp {

   public static void main(String[] args) {
      Text text = new Text(
            "Hello this is an example of a sentence containing words");

      System.out.println("*** Words containing 'e' ***");
      text.printFilteredWords(s -> s.contains("e")) ;
      
      System.out.println("*** Long words ***");
      text.printFilteredWords(s -> s.length()  > 4) ;
      
      System.out.println("*** Words starting with 'a' ***");
      text.printFilteredWords(s -> s.startsWith("a")) ;
    
      System.out.println("*** Words containing 'e' on second position ***");
      text.printFilteredWords(s -> s.indexOf('e') == 1) ;

      System.out.println("*** Words containing 2x 'e' ***");
      text.printFilteredWords(s -> {
         int count = 0;
         for(char c : s.toCharArray()){
            if(c == 'e') count++;
         }
         return count == 2;         
      }) ;
   }
}
