package exercise07_05;
public class Statistics {
   public static int average(int... values) {
      int total = 0;
      for (int el : values) {
         total += el;
      }
      return total;
   }

   public static int min(int... values) {
      int min = Integer.MAX_VALUE;
      for (int el : values) {
         if(el < min) min =el;
      }
      return min;
   }

   public static int max(int... values) {
      int max = Integer.MIN_VALUE;
      for (int el : values) {
         if(el > max) max =el;
      }
      return max;
   }

}