package exercise14_03;

public class Musician {
   public void play() {
      Instrument instrument = new Instrument() {
         public void makeNoise() {
            System.out.println("plong");
         }
      };
      instrument.makeNoise();
   }
}
