package exercise14_03;

public interface Instrument {
   public abstract void makeNoise();

}
