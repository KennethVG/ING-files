package exercise14_03;

public class MusicianApp {
   
   public static void main(String[] args) {
      Musician musician = new Musician();
      musician.play();      
   }
}
