package exercise10_01.graphics;

public class SquareApp {
	public static void main(String[] args) {
		Square square = new Square();
	}
}
