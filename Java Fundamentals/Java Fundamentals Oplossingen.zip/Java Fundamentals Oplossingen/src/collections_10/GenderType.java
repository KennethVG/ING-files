package collections_10;

public enum GenderType {
   MALE,FEMALE;
}
