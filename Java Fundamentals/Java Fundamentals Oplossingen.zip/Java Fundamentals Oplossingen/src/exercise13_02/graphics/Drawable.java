package exercise13_02.graphics;

import java.awt.*;

public interface Drawable extends Scaleable{
	public void draw(Graphics g);
}
