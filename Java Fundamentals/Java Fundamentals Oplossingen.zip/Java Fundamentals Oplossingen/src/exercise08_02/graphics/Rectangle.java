package exercise08_02.graphics;

public class Rectangle {

}
