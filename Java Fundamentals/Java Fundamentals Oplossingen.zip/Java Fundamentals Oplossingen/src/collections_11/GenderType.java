package collections_11;

public enum GenderType {
   MALE,FEMALE;
}
