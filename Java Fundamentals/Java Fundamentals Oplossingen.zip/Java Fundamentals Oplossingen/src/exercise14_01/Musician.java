package exercise14_01;

public class Musician {
		
   public class Instrument {
      public void makeNoice() {
         System.out.println("plong" );
      }
   }
   
   public void play() {
      Instrument piano = new Instrument();
      piano.makeNoice();
   } 
}
