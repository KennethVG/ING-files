package collections_13;

public enum GenderType {
   MALE,FEMALE;
}
