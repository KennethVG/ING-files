package streams_04;

public enum GenderType {
   MALE,FEMALE;
}
