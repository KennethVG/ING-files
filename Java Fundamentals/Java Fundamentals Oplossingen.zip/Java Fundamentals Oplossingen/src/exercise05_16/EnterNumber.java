package exercise05_16;

import java.util.*;

public class EnterNumber {
   public static void main(String[] args) {
      Scanner keyboard = new Scanner(System.in);
      int value = -1;
      while(value < 0 || value > 10) {
         System.out.println("Enter number between 0 and 10: ");
         value = keyboard.nextInt();         
      }
      System.out.println("You entered :" + value);
      keyboard.close();
   }
}