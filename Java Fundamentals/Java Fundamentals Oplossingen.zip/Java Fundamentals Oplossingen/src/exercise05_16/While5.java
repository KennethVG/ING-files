package exercise05_16;

public class While5{
   public static void main(String[] args)  {
      int a=1;    
      do {
         System.out.println(a);
         a<<=1;
      }
      while(a < 10000);
   }
}