package exercise05_16;

public class While2{
   public static void main(String[] args)    {
      int multiple = 0;   
      while(multiple < 50) {
         System.out.println(multiple);
         multiple+=3;
      }
   }
}