package exercise05_04;
import java.util.*;

public class Arithmetic {
	public static void main(String[] args) {
	   Scanner keyboard = new Scanner(System.in);
	   		
	   int number1 = keyboard.nextInt();
		int number2 = keyboard.nextInt();
		char c = 'a';
		
		System.out.println("Het eerste number is: " + number1);
		System.out.println("Het tweede number is: " + number2);
		System.out.println("De som is          : " + (number1 + number2));
		System.out.println("Het verschil is    : " + (number1 - number2));
		System.out.println("Het product is     : " + (number1 * number2));
		System.out.println("De deling is       : " + (number1 / number2));
		System.out.println("De rest is         : " + (number1 % number2));
		System.out.println("Het eerste number +1: " + (++number1));
		System.out.println("Het tweede number -1: " + (--number2));
      System.out.println("Het eerste number +1: " + (number1++));
      System.out.println("Het tweede number -1: " + (number2--));
      System.out.println("Het karakter c     : " + c);
      System.out.println("Het karakter c++   : " + c++);
      System.out.println("Het karakter c     : " + c);     
      keyboard.close();      
	}
}