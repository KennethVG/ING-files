package exercise07_01;

public class BooleanArray {

   public static void main(String[] args) {
      boolean[] bs = {true, false, false, true, true};
      
      for(boolean b: bs) {
         System.out.println(b);
      }
   }

}
