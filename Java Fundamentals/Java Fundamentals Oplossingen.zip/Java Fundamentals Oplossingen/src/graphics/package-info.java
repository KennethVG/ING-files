/**
 * The package <b>graphics</b> contains classes and interfaces
 * which represent graphical shapes.
 */
package graphics;

