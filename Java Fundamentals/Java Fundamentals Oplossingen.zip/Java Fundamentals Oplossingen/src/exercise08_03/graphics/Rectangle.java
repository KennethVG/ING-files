package exercise08_03.graphics;

public class Rectangle {
	public int width;
	public int height;
	public int x;
	public int y;
}
