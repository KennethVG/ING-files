package collections_08;

public enum GenderType {
   MALE,FEMALE;
}
