package exercise14_04.graphics;

import java.awt.*;

public interface Drawable extends Scaleable{
	public void draw(Graphics g);
}
