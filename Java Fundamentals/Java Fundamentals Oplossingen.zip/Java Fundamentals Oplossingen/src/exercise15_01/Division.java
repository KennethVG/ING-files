package exercise15_01;

import java.util.*;

public class Division {
	public static void main(String args[]) {
	   Scanner keyboard = new Scanner(System.in);	   
		int numerator = Integer.parseInt(keyboard.next());
		int denominator = Integer.parseInt(keyboard.next());
		int division = numerator / denominator;

		System.out.println(numerator + "/" + denominator + "="
				+ division);
		keyboard.close();
	}
}