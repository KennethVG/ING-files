package streams_03;

public enum GenderType {
   MALE,FEMALE;
}
