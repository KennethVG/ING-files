package exercise14_02;

public class Musician {
   public void play() {
      class Instrument {
         public void makeNoise() {
            System.out.println("plong");
         }
      }
      Instrument instrument = new Instrument();
      instrument.makeNoise();
   }
}
