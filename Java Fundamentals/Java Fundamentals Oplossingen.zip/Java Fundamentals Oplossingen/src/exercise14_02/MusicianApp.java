package exercise14_02;

public class MusicianApp {
   
   public static void main(String[] args) {
      Musician musician = new Musician();
      musician.play();
      
   }
}
