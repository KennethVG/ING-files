package exercise07_04;

public class LookupTableSample {

   public static void main(String[] args) {
      int[] months = {31,28,31,30,31,30,31,31,30,31,30,31};
      int month = 5;      
      System.out.println(months[month-1]);
      
   }

}
