package exercise05_17;

public class For1 {
   public static void main(String[] args) {
      for (int number = 400; number >= 350; number--) {
         System.out.println(number);
      }
   }
}