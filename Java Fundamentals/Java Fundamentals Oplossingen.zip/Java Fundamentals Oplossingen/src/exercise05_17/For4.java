package exercise05_17;

public class For4 {
   public static void main(String[] args) {
      for (char character = 'z'; character >= 'a'; character--) {
         System.out.println(character);
      }
   }
}