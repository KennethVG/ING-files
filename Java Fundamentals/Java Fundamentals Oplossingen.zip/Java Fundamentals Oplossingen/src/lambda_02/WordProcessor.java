package lambda_02;

@FunctionalInterface
public interface WordProcessor {
   public String process(String s);
}
