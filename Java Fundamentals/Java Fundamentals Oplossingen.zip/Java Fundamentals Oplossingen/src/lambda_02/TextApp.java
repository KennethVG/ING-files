package lambda_02;

public class TextApp {
   public static void main(String[] args) {
      Text text = new Text(
            "Hello this is an example of a sentence containing words");

      // Static methods
      text.printProcessedWords(s -> String.format("<<%s>>",s ));      
      text.printProcessedWords(s -> TextUtil.quote(s));
      text.printProcessedWords(TextUtil::quote);

      text.printProcessedWords(s -> TextUtil.reverse(s));
      text.printProcessedWords(TextUtil::reverse);

      // Non static bound methods
      TextPadder padder = new TextPadder(20);
      text.printProcessedWords(s -> padder.pad(s));
      text.printProcessedWords(padder::pad);

      TextScrambler scrambler = new TextScrambler();
      text.printProcessedWords(scrambler::scramble);
      
      // Non static unbound methods
      text.printProcessedWords(s -> s.toUpperCase());
      text.printProcessedWords(String::toUpperCase);
      
      // Constructor reference
      text = new Text("145 236 9852 3658");
      text.printNumberValues(s -> new Double(s));      
      text.printNumberValues(Double::new);
   }
}
