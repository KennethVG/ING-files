package exercise05_18;

import java.util.Scanner;

public class KeyboardUtility {
   public static int readInt() {
      Scanner keyboard = new Scanner(System.in);
      return keyboard.nextInt();
   }
}
