package exercise05_05;

public class TempResult {
   public static void main(String[] args) {
      int number1 = 2147483645;
      int number2 = 2147483645;
      long result = ((long) number1) * number2;
      System.out.println(result);
   }
}
